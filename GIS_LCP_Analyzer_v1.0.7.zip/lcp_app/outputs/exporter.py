"""
Output Exporter
================
Handles final output generation:
  - GeoTIFF rasters
  - Shapefile
  - KML
  - Metadata report
"""

import logging
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)


class OutputExporter:
    """Manages export of analysis results."""

    def __init__(self, output_dir: str, prefix: str = "lcp") -> None:
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.prefix = prefix
        self._exported: dict[str, str] = {}

    def copy_raster(self, src: str, name: str) -> str:
        """Copy a raster to the output folder with a standardised name."""
        import shutil
        dst = str(self.output_dir / f"{self.prefix}_{name}.tif")
        shutil.copy2(src, dst)
        self._exported[name] = dst
        logger.info("Exported raster: %s", dst)
        return dst

    def write_metadata_report(
        self,
        layers: list,
        ahp_weights: dict,
        cr: float,
        path_length_m: float,
    ) -> str:
        """Generate a JSON metadata report."""
        report = {
            "application": "GIS LCP Analyzer",
            "reference": "GIS-TL-DS-2026-001",
            "generated_at": datetime.now().isoformat(),
            "ahp_weights": ahp_weights,
            "cr": cr,
            "optimal_path_length_m": path_length_m,
            "optimal_path_length_km": round(path_length_m / 1000, 3),
            "layers": [
                {
                    "name": lyr.display_name,
                    "role": lyr.role.value,
                    "crs": lyr.crs,
                    "weight": ahp_weights.get(lyr.role.value, 0),
                }
                for lyr in layers
            ],
            "outputs": self._exported,
        }
        out_path = str(self.output_dir / f"{self.prefix}_metadata.json")
        with open(out_path, "w") as f:
            json.dump(report, f, indent=2)
        logger.info("Metadata report written: %s", out_path)
        return out_path

    def list_outputs(self) -> dict[str, str]:
        return dict(self._exported)
