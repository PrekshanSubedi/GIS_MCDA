#!/usr/bin/env python3
"""
GIS Least Cost Path Analysis Application
=========================================
Main entry point for the desktop GUI application.

Application: GIS-LCP-Analyzer
Version: 1.0.0
Reference: GIS-TL-DS-2026-001
"""

import sys
import os
import logging
from pathlib import Path

# Ensure the application root is on the Python path
APP_ROOT = Path(__file__).parent
sys.path.insert(0, str(APP_ROOT))

from PyQt5.QtWidgets import QApplication, QSplashScreen
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont

from gui.main_window import MainWindow
from utils.logger import setup_logging
from utils.config import AppConfig


def main() -> None:
    """Main application entry point."""
    # Set up logging before anything else
    setup_logging()
    logger = logging.getLogger(__name__)
    logger.info("Starting GIS Least Cost Path Analyzer v1.0.0")

    # Load application configuration
    config = AppConfig()

    # Create the Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("GIS LCP Analyzer")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("GIS-TL-DS")

    # Apply stylesheet
    _apply_stylesheet(app, config.get("theme", "dark"))

    # Show splash screen
    splash = _create_splash()
    if splash:
        splash.show()
        app.processEvents()

    # Create and show main window
    window = MainWindow(config)
    window.show()

    if splash:
        splash.finish(window)

    logger.info("Application window displayed")
    sys.exit(app.exec_())


def _create_splash() -> QSplashScreen | None:
    """Create a simple splash screen."""
    try:
        pixmap = QPixmap(600, 300)
        pixmap.fill(Qt.black)
        splash = QSplashScreen(pixmap, Qt.WindowStaysOnTopHint)
        splash.showMessage(
            "GIS Least Cost Path Analyzer\nLoading...",
            Qt.AlignCenter | Qt.AlignBottom,
            Qt.white
        )
        return splash
    except Exception:
        return None


def _apply_stylesheet(app: QApplication, theme: str) -> None:
    """Apply the application stylesheet."""
    if theme == "dark":
        app.setStyleSheet(_DARK_STYLESHEET)
    else:
        app.setStyleSheet(_LIGHT_STYLESHEET)


_DARK_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #1e1e2e;
    color: #cdd6f4;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
}
QMenuBar {
    background-color: #181825;
    color: #cdd6f4;
    padding: 2px;
}
QMenuBar::item:selected {
    background-color: #313244;
}
QMenu {
    background-color: #181825;
    color: #cdd6f4;
    border: 1px solid #45475a;
}
QMenu::item:selected {
    background-color: #313244;
}
QToolBar {
    background-color: #181825;
    border: none;
    spacing: 4px;
    padding: 2px;
}
QToolButton {
    background-color: #313244;
    border: 1px solid #45475a;
    border-radius: 4px;
    padding: 4px 8px;
    color: #cdd6f4;
}
QToolButton:hover {
    background-color: #45475a;
}
QToolButton:pressed {
    background-color: #585b70;
}
QGroupBox {
    border: 1px solid #45475a;
    border-radius: 6px;
    margin-top: 12px;
    padding-top: 8px;
    font-weight: bold;
    color: #89b4fa;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
}
QPushButton {
    background-color: #313244;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 6px 14px;
    color: #cdd6f4;
    min-height: 24px;
}
QPushButton:hover {
    background-color: #45475a;
    border-color: #89b4fa;
}
QPushButton:pressed {
    background-color: #585b70;
}
QPushButton:disabled {
    background-color: #181825;
    color: #585b70;
    border-color: #313244;
}
QPushButton#primary {
    background-color: #89b4fa;
    color: #1e1e2e;
    font-weight: bold;
}
QPushButton#primary:hover {
    background-color: #b4d0ff;
}
QPushButton#danger {
    background-color: #f38ba8;
    color: #1e1e2e;
    font-weight: bold;
}
QPushButton#success {
    background-color: #a6e3a1;
    color: #1e1e2e;
    font-weight: bold;
}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #313244;
    border: 1px solid #45475a;
    border-radius: 4px;
    padding: 4px 8px;
    color: #cdd6f4;
    selection-background-color: #89b4fa;
}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {
    border-color: #89b4fa;
}
QComboBox::drop-down {
    border: none;
    width: 20px;
}
QComboBox QAbstractItemView {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    selection-background-color: #45475a;
}
QTableWidget, QTableView {
    background-color: #181825;
    gridline-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    selection-background-color: #313244;
}
QTableWidget::item:selected, QTableView::item:selected {
    background-color: #45475a;
}
QHeaderView::section {
    background-color: #313244;
    color: #89b4fa;
    padding: 6px;
    border: 1px solid #45475a;
    font-weight: bold;
}
QTreeWidget, QListWidget {
    background-color: #181825;
    color: #cdd6f4;
    border: 1px solid #45475a;
    alternate-background-color: #1e1e2e;
}
QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #313244;
    color: #89b4fa;
}
QTreeWidget::item:hover, QListWidget::item:hover {
    background-color: #252535;
}
QTabWidget::pane {
    border: 1px solid #45475a;
    background-color: #1e1e2e;
}
QTabBar::tab {
    background-color: #181825;
    color: #6c7086;
    padding: 8px 16px;
    border: 1px solid #45475a;
    border-bottom: none;
    border-radius: 4px 4px 0 0;
}
QTabBar::tab:selected {
    background-color: #1e1e2e;
    color: #89b4fa;
    font-weight: bold;
}
QTabBar::tab:hover:!selected {
    background-color: #252535;
    color: #cdd6f4;
}
QScrollBar:vertical {
    background-color: #181825;
    width: 12px;
}
QScrollBar::handle:vertical {
    background-color: #45475a;
    border-radius: 6px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover {
    background-color: #585b70;
}
QScrollBar:horizontal {
    background-color: #181825;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background-color: #45475a;
    border-radius: 6px;
    min-width: 20px;
}
QProgressBar {
    background-color: #313244;
    border: 1px solid #45475a;
    border-radius: 4px;
    text-align: center;
    color: #cdd6f4;
    height: 18px;
}
QProgressBar::chunk {
    background-color: #89b4fa;
    border-radius: 3px;
}
QSplitter::handle {
    background-color: #45475a;
}
QSplitter::handle:horizontal {
    width: 3px;
}
QSplitter::handle:vertical {
    height: 3px;
}
QCheckBox {
    spacing: 6px;
    color: #cdd6f4;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border: 1px solid #45475a;
    border-radius: 3px;
    background-color: #313244;
}
QCheckBox::indicator:checked {
    background-color: #89b4fa;
    border-color: #89b4fa;
}
QLabel#title {
    font-size: 16px;
    font-weight: bold;
    color: #89b4fa;
}
QLabel#subtitle {
    font-size: 11px;
    color: #6c7086;
}
QTextEdit {
    background-color: #181825;
    color: #a6e3a1;
    border: 1px solid #45475a;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 12px;
}
QStatusBar {
    background-color: #181825;
    color: #6c7086;
    border-top: 1px solid #313244;
}
"""

_LIGHT_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #f8f9fa;
    color: #2d2d2d;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
}
QGroupBox {
    border: 1px solid #dee2e6;
    border-radius: 6px;
    margin-top: 12px;
    padding-top: 8px;
    font-weight: bold;
    color: #1a73e8;
}
QPushButton {
    background-color: #ffffff;
    border: 1px solid #ced4da;
    border-radius: 6px;
    padding: 6px 14px;
    color: #2d2d2d;
}
QPushButton:hover {
    background-color: #e9ecef;
}
QPushButton#primary {
    background-color: #1a73e8;
    color: white;
    font-weight: bold;
}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #ffffff;
    border: 1px solid #ced4da;
    border-radius: 4px;
    padding: 4px 8px;
}
QProgressBar::chunk {
    background-color: #1a73e8;
}
QTextEdit {
    background-color: #1e1e1e;
    color: #00ff88;
    font-family: monospace;
}
"""


if __name__ == "__main__":
    main()
