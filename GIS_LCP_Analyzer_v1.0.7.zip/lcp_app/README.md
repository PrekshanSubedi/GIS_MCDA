# GIS Least Cost Path Analyzer

**Reference:** GIS-TL-DS-2026-001  
**Version:** 1.0.0  
**Python:** 3.11+

A production-ready desktop GIS application for **Least Cost Path (LCP) analysis** using **Analytical Hierarchy Process (AHP)**-based weighted overlay analysis. Designed for infrastructure corridor alignment (transmission lines, roads, pipelines).

---

## Features

| Module | Capability |
|--------|-----------|
| **Data Input** | Buildings, Settlements, DEM, LULC, Waterways, Roads, Study Corridor |
| **CRS Management** | Auto-detect, reproject all layers to a common CRS |
| **DEM Derivatives** | Slope (degrees), Terrain Ruggedness Index (TRI) |
| **Building Constraints** | User-defined buffer (0–500 m) as absolute barriers |
| **Rasterization** | Vector → aligned raster at DEM resolution |
| **Euclidean Distance** | Distance rasters from point/line/polygon features |
| **Reclassification** | User-editable tables, cost scale 1–9 |
| **AHP Engine** | Eigenvector weights, CI, CR, Excel import/export |
| **Weighted Overlay** | Weighted Linear Combination (WLC) cost surface |
| **LCP Analysis** | Dijkstra 8-connected, cost distance, backlink, path trace |
| **Outputs** | GeoTIFF, Shapefile, KML, JSON metadata |
| **Map Canvas** | Matplotlib inline viewer, zoom/pan, colormaps |
| **Themes** | Dark (default) and Light |
| **Project Save/Load** | JSON-based `.lcpproj` files |

---

## Installation

### Option 1 — Conda (Recommended)

```bash
conda create -n gis_lcp python=3.11
conda activate gis_lcp
conda install -c conda-forge gdal rasterio geopandas fiona shapely pyproj scipy
pip install PyQt5 matplotlib pandas openpyxl
pip install -r requirements.txt
```

### Option 2 — pip only

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

> **Note:** GDAL via pip can be tricky on Windows. Use OSGeo4W or Conda on Windows.

---

## Running the Application

```bash
cd lcp_app
python main.py
```

---

## Workflow

```
1. Load Datasets          →  Input tab: Buildings, DEM, LULC, Waterways, Roads, etc.
2. Reproject              →  CRS tab: select EPSG, click "Reproject All Layers"
3. DEM Derivatives        →  DEM tab: generate Slope + TRI
4. Distance Rasters       →  Auto-generated for vector layers
5. Reclassification       →  Reclass tab: edit cost tables (1=best, 9=worst)
6. AHP Matrix             →  AHP tab: edit matrix, verify CR < 0.10
7. Weighted Overlay       →  Overlay tab: run WLC cost surface
8. Set Start/End Points   →  LCP tab: type lat/lon or click map canvas
9. Run LCP                →  LCP tab: Dijkstra analysis
10. Export Outputs        →  Output tab: select folder, generate all outputs
```

---

## AHP Matrix (Default — GIS-TL-DS-2026-001)

| Criterion | Buildings | Settlement | Slope | TRI | Land Use | Waterways | Roads |
|-----------|-----------|------------|-------|-----|----------|-----------|-------|
| **Buildings** | 1 | 2 | 5 | 5 | 7 | 7 | 9 |
| **Settlement** | 1/2 | 1 | 3 | 3 | 5 | 5 | 7 |
| **Slope** | 1/5 | 1/3 | 1 | 2 | 3 | 3 | 5 |
| **TRI** | 1/5 | 1/3 | 1/2 | 1 | 3 | 3 | 5 |
| **Land Use** | 1/7 | 1/5 | 1/3 | 1/3 | 1 | 2 | 3 |
| **Waterways** | 1/7 | 1/5 | 1/3 | 1/3 | 1/2 | 1 | 3 |
| **Roads** | 1/9 | 1/7 | 1/5 | 1/5 | 1/3 | 1/3 | 1 |

CR must be ≤ 0.10 (Saaty, 1980). RI for n=7 is 1.32.

---

## Reclassification Scales

### Slope
| Range | Cost | Category |
|-------|------|----------|
| 0–5° | 1 | Flat |
| 5–15° | 3 | Gentle |
| 15–25° | 5 | Moderate |
| 25–35° | 7 | Steep |
| >35° | 9 | Very Steep |

### LULC
| Class | Cost | Category |
|-------|------|----------|
| 10 Grassland | 1 | Low |
| 7 Cropland | 2 | Low-Moderate |
| 4 Forest | 5 | Moderate-High |
| 6 Built-up | 9 | Very High |

Full tables editable in the Reclassification tab.

---

## Output Files

| File | Description |
|------|-------------|
| `lcp_cost_distance.tif` | Accumulated cost from source point |
| `lcp_backlink.tif` | Direction raster (8 directions) |
| `lcp_path_raster.tif` | Binary least cost path mask |
| `lcp_optimal_route.shp` | Optimal route as polyline shapefile |
| `lcp_optimal_route.kml` | Optimal route as KML |
| `lcp_metadata.json` | Analysis metadata and AHP weights |

---

## Project File Format

Projects are saved as `.lcpproj` (JSON):

```json
{
  "version": "1.0",
  "layers": [...],
  "ahp_matrix": [[1, 2, ...], ...],
  "ahp_criteria": ["Buildings", "Settlement", ...],
  "settings": {}
}
```

---

## Packaging as Executable

```bash
pip install pyinstaller

# Windows
pyinstaller --onefile --windowed --name GIS_LCP_Analyzer main.py

# Linux / macOS
pyinstaller --onefile --name GIS_LCP_Analyzer main.py
```

Executable will be in `dist/`.

> For GDAL on Windows, add `--add-data "path/to/gdal/data;gdal-data"` to the PyInstaller command.

---

## Project Structure

```
lcp_app/
├── main.py                    # Entry point
├── requirements.txt
├── README.md
├── gui/
│   ├── main_window.py         # Main window orchestrator
│   ├── layer_panel.py         # Left layer management panel
│   ├── map_canvas.py          # Matplotlib map viewer
│   ├── analysis_panel.py      # Right analysis tools panel
│   ├── ahp_widget.py          # AHP matrix editor
│   └── log_console.py         # Bottom log + progress
├── ahp/
│   └── ahp_engine.py          # AHP calculation (eigenvector, CI, CR)
├── core/
│   ├── layer_model.py         # Layer data model
│   └── project_manager.py     # Save/load project
├── raster/
│   └── raster_processor.py    # GDAL/Rasterio operations
├── vector/
│   └── vector_utils.py        # GeoPandas utilities
├── processing/
│   ├── lcp_engine.py          # Dijkstra LCP engine
│   └── workers.py             # QThread background workers
├── outputs/
│   └── exporter.py            # Output file manager
└── utils/
    ├── config.py              # App configuration
    ├── logger.py              # Logging setup
    └── helpers.py             # Utility functions
```

---

## Algorithm Details

### AHP (Analytical Hierarchy Process)
1. Build n×n pairwise comparison matrix
2. Normalise by column sums
3. Priority vector = row means of normalised matrix
4. λmax = mean of (PCM × w) / w
5. CI = (λmax − n) / (n − 1)
6. CR = CI / RI; must be < 0.10

### Least Cost Path (Dijkstra)
1. Load WLC cost surface
2. Priority queue from source cell
3. 8-connected movement; step cost = avg(c_current, c_neighbour) × pixel_size × √2 (diagonal)
4. Backlink raster records direction to each reached cell
5. Path traced from destination back to source via backlinks

### Weighted Linear Combination
```
Cost = Σ(wi × Li)
```
where wi = AHP weight, Li = reclassified raster (1–9 scale).
Building buffer zones → set to 9999 (absolute barriers).

---

## References

- Saaty, T.L. (1980). *The Analytic Hierarchy Process*. McGraw-Hill.
- Riley, S.J. et al. (1999). *A terrain ruggedness index that quantifies topographic heterogeneity*. Intermtn J Sci.
- GDAL/OGR contributors (2024). *GDAL/OGR Geospatial Data Abstraction software Library*.
