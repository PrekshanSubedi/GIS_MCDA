"""
Background Worker Threads
==========================
PyQt5 QThread-based workers for all long-running GIS operations.
Each worker emits progress (0-100), log messages, finished dict, or error string.
"""

import logging
import traceback
from pathlib import Path
from typing import Any, Optional

from PyQt5.QtCore import QThread, pyqtSignal, QObject

logger = logging.getLogger(__name__)


class WorkerSignals(QObject):
    progress = pyqtSignal(int)
    log      = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error    = pyqtSignal(str)


class BaseWorker(QThread):
    def __init__(self) -> None:
        super().__init__()
        self.signals = WorkerSignals()
        self._cancelled = False

    def cancel(self) -> None:
        self._cancelled = True

    def _progress(self, frac: float) -> None:
        if not self._cancelled:
            self.signals.progress.emit(int(min(max(frac, 0.0), 1.0) * 100))

    def _log(self, msg: str) -> None:
        self.signals.log.emit(msg)
        safe = msg.encode("ascii", errors="replace").decode("ascii")
        logger.info(safe)

    def run(self) -> None:
        try:
            result = self._execute()
            if not self._cancelled:
                self.signals.finished.emit(result or {})
        except Exception as e:
            tb = traceback.format_exc()
            logger.error("Worker error: %s\n%s", e, tb)
            self.signals.error.emit(f"{type(e).__name__}: {e}\n\n{tb}")

    def _execute(self) -> dict[str, Any]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Reproject Worker
# ---------------------------------------------------------------------------
class ReprojectWorker(BaseWorker):
    def __init__(self, layers: list, target_crs: str, workspace: str) -> None:
        super().__init__()
        self.layers    = layers
        self.target_crs = target_crs
        self.workspace  = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import reproject_raster, reproject_vector, get_raster_info
        from core.layer_model import LayerType
        self.workspace.mkdir(parents=True, exist_ok=True)
        results = {}
        for i, layer in enumerate(self.layers):
            if self._cancelled:
                break
            self._log(f"Reprojecting: {layer.display_name}")
            out = str(self.workspace / f"reproj_{layer.layer_id}_{Path(layer.file_path).name}")
            try:
                if layer.is_raster:
                    reproject_raster(layer.file_path, out, self.target_crs)
                    info = get_raster_info(out)
                    layer.reprojected_path = out
                    layer.crs = info.get("crs", self.target_crs)
                else:
                    reproject_vector(layer.file_path, out, self.target_crs)
                    layer.reprojected_path = out
                    layer.crs = self.target_crs
                results[layer.layer_id] = out
                self._log(f"  [OK] {layer.display_name}")
            except Exception as e:
                self._log(f"  [ERR] {layer.display_name}: {e}")
            self._progress((i + 1) / len(self.layers))
        return results


# ---------------------------------------------------------------------------
# Corridor Clip Worker  (NEW)
# ---------------------------------------------------------------------------
class CorridorClipWorker(BaseWorker):
    """Clip all raster layers to the study corridor boundary."""

    def __init__(
        self,
        raster_paths: dict[str, str],   # {layer_id: path}
        corridor_path: str,
        workspace: str,
    ) -> None:
        super().__init__()
        self.raster_paths  = raster_paths
        self.corridor_path = corridor_path
        self.workspace     = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import clip_raster_to_polygon
        self.workspace.mkdir(parents=True, exist_ok=True)
        results = {}
        items = list(self.raster_paths.items())
        for i, (lid, src) in enumerate(items):
            if self._cancelled:
                break
            name = Path(src).stem
            self._log(f"Clipping to corridor: {name}")
            out = str(self.workspace / f"clip_{lid}.tif")
            try:
                clip_raster_to_polygon(src, out, self.corridor_path)
                results[lid] = out
                self._log(f"  [OK] {name}")
            except Exception as e:
                self._log(f"  [ERR] {name}: {e}")
                results[lid] = src   # fall back to unclipped
            self._progress((i + 1) / len(items))
        return results


# ---------------------------------------------------------------------------
# DEM Derivatives Worker
# ---------------------------------------------------------------------------
class DEMDerivativesWorker(BaseWorker):
    def __init__(self, dem_path: str, workspace: str) -> None:
        super().__init__()
        self.dem_path  = dem_path
        self.workspace = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import compute_slope, compute_tri
        self.workspace.mkdir(parents=True, exist_ok=True)
        results = {}
        self._log("Computing slope...")
        slope_path = str(self.workspace / "slope.tif")
        compute_slope(self.dem_path, slope_path, units="degree",
                      progress_cb=lambda f: self._progress(f * 0.5))
        results["slope"] = slope_path
        self._log(f"  [OK] Slope: {slope_path}")
        if self._cancelled:
            return results
        self._log("Computing TRI...")
        tri_path = str(self.workspace / "tri.tif")
        compute_tri(self.dem_path, tri_path,
                    progress_cb=lambda f: self._progress(0.5 + f * 0.5))
        results["tri"] = tri_path
        self._log(f"  [OK] TRI: {tri_path}")
        return results


# ---------------------------------------------------------------------------
# Full Rasterization Pipeline Worker  (NEW - all vectors → rasters)
# ---------------------------------------------------------------------------
class FullRasterizationWorker(BaseWorker):
    """
    Convert every vector layer to a raster aligned to the reference DEM,
    then compute Euclidean distance rasters for proximity-based criteria.
    Also rasterizes settlement points by place type (town/village/suburb/hamlet).
    """

    def __init__(
        self,
        layers: list,               # all LayerInfo objects
        reference_raster: str,      # clipped/reprojected DEM
        workspace: str,
        building_buffer_m: float = 20.0,
    ) -> None:
        super().__init__()
        self.layers            = layers
        self.reference_raster  = reference_raster
        self.workspace         = Path(workspace)
        self.building_buffer_m = building_buffer_m

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import (
            rasterize_vector,
            euclidean_distance_raster,
            rasterize_settlement_types,
            create_building_constraint_mask,
        )
        from core.layer_model import LayerRole
        self.workspace.mkdir(parents=True, exist_ok=True)
        results: dict[str, Any] = {
            "distance_rasters": {},
            "type_rasters": {},
            "constraint_mask": None,
        }

        # Categorise layers
        buildings_lyr   = None
        settlements_lyr = None
        waterways_lyrs  = []
        roads_lyrs      = []

        for lyr in self.layers:
            if not lyr.is_vector:
                continue
            r = lyr.role
            if r == LayerRole.BUILDINGS:
                buildings_lyr = lyr
            elif r == LayerRole.SETTLEMENTS:
                settlements_lyr = lyr
            elif r == LayerRole.WATERWAYS:
                waterways_lyrs.append(lyr)
            elif r == LayerRole.ROADS:
                roads_lyrs.append(lyr)

        total_steps = sum([
            bool(buildings_lyr),
            bool(settlements_lyr) * 2,   # type raster + distance raster
            bool(waterways_lyrs),
            bool(roads_lyrs),
        ]) or 1
        step = 0

        # 1. Building constraint mask
        if buildings_lyr:
            src = buildings_lyr.reprojected_path or buildings_lyr.file_path
            out = str(self.workspace / "building_constraint.tif")
            self._log(f"Building constraint mask (buffer={self.building_buffer_m}m)...")
            try:
                create_building_constraint_mask(
                    src, out, self.reference_raster, self.building_buffer_m
                )
                results["constraint_mask"] = out
                self._log("  [OK] Building constraint mask")
            except Exception as e:
                self._log(f"  [ERR] Building constraint: {e}")
            step += 1
            self._progress(step / total_steps)

        # 2. Settlement type raster + distance raster
        if settlements_lyr:
            src = settlements_lyr.reprojected_path or settlements_lyr.file_path
            # Type raster (town=1 … hamlet=4)
            type_out = str(self.workspace / "settlement_type.tif")
            self._log("Rasterizing settlements by place type...")
            try:
                rasterize_settlement_types(src, type_out, self.reference_raster)
                results["type_rasters"]["settlement"] = type_out
                self._log("  [OK] Settlement type raster (Town=1,Village=2,Suburb=3,Hamlet=4)")
            except Exception as e:
                self._log(f"  [ERR] Settlement type: {e}")
            step += 1
            self._progress(step / total_steps)

            # Distance raster
            dist_out = str(self.workspace / "dist_settlements.tif")
            self._log("Settlement distance raster...")
            try:
                euclidean_distance_raster(src, dist_out, self.reference_raster)
                results["distance_rasters"]["settlement"] = dist_out
                self._log("  [OK] Settlement distance raster")
            except Exception as e:
                self._log(f"  [ERR] Settlement distance: {e}")
            step += 1
            self._progress(step / total_steps)

        # 3. Waterway distance raster
        if waterways_lyrs:
            src = waterways_lyrs[0].reprojected_path or waterways_lyrs[0].file_path
            dist_out = str(self.workspace / "dist_waterways.tif")
            self._log("Waterway distance raster...")
            try:
                euclidean_distance_raster(src, dist_out, self.reference_raster)
                results["distance_rasters"]["waterway"] = dist_out
                self._log("  [OK] Waterway distance raster")
            except Exception as e:
                self._log(f"  [ERR] Waterway distance: {e}")
            step += 1
            self._progress(step / total_steps)

        # 4. Road distance raster
        if roads_lyrs:
            src = roads_lyrs[0].reprojected_path or roads_lyrs[0].file_path
            dist_out = str(self.workspace / "dist_roads.tif")
            self._log("Road distance raster...")
            try:
                euclidean_distance_raster(src, dist_out, self.reference_raster)
                results["distance_rasters"]["road"] = dist_out
                self._log("  [OK] Road distance raster")
            except Exception as e:
                self._log(f"  [ERR] Road distance: {e}")
            step += 1
            self._progress(step / total_steps)

        self._progress(1.0)
        return results


# ---------------------------------------------------------------------------
# Reclassify Worker
# ---------------------------------------------------------------------------
class ReclassifyWorker(BaseWorker):
    def __init__(self, raster_tables: list[dict], workspace: str) -> None:
        super().__init__()
        self.raster_tables = raster_tables
        self.workspace     = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import reclassify_raster
        self.workspace.mkdir(parents=True, exist_ok=True)
        results = {}
        for i, item in enumerate(self.raster_tables):
            if self._cancelled:
                break
            src   = item["src"]
            table = item["table"]
            lid   = item["id"]
            name  = Path(src).stem
            self._log(f"Reclassifying: {name}")
            out = str(self.workspace / f"reclass_{lid}.tif")
            try:
                reclassify_raster(src, out, table)
                results[lid] = out
                self._log(f"  [OK] {name}")
            except Exception as e:
                self._log(f"  [ERR] {name}: {e}")
            self._progress((i + 1) / len(self.raster_tables))
        return results


# ---------------------------------------------------------------------------
# Building Constraint Worker
# ---------------------------------------------------------------------------
class BuildingConstraintWorker(BaseWorker):
    def __init__(self, building_path: str, reference_raster: str,
                 buffer_m: float, workspace: str) -> None:
        super().__init__()
        self.building_path    = building_path
        self.reference_raster = reference_raster
        self.buffer_m         = buffer_m
        self.workspace        = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import create_building_constraint_mask
        self.workspace.mkdir(parents=True, exist_ok=True)
        out = str(self.workspace / "building_constraint.tif")
        self._log(f"Building constraint mask (buffer={self.buffer_m}m)...")
        create_building_constraint_mask(
            self.building_path, out, self.reference_raster,
            self.buffer_m, progress_cb=self._progress)
        self._log(f"  [OK] Constraint mask: {out}")
        return {"constraint_mask": out}


# ---------------------------------------------------------------------------
# Weighted Overlay Worker
# ---------------------------------------------------------------------------
class WeightedOverlayWorker(BaseWorker):
    def __init__(self, layer_paths: list[str], weights: list[float],
                 output_path: str, constraint_mask_path: Optional[str] = None) -> None:
        super().__init__()
        self.layer_paths          = layer_paths
        self.weights              = weights
        self.output_path          = output_path
        self.constraint_mask_path = constraint_mask_path

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import compute_wlc_cost_surface
        self._log("Computing weighted overlay (WLC) cost surface...")
        criteria_info = [f"{w:.3f}" for w in self.weights]
        self._log(f"  Layers: {len(self.layer_paths)}, Weights: {criteria_info}")
        compute_wlc_cost_surface(
            self.layer_paths, self.weights, self.output_path,
            constraint_mask_path=self.constraint_mask_path,
            progress_cb=self._progress)
        self._log(f"  [OK] Cost surface: {self.output_path}")
        return {"cost_surface": self.output_path}


# ---------------------------------------------------------------------------
# Settlement Type Worker
# ---------------------------------------------------------------------------
class SettlementTypeWorker(BaseWorker):
    def __init__(self, settlement_path: str, reference_raster: str,
                 workspace: str, place_field: str = "place") -> None:
        super().__init__()
        self.settlement_path  = settlement_path
        self.reference_raster = reference_raster
        self.workspace        = Path(workspace)
        self.place_field      = place_field

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import rasterize_settlement_types
        self.workspace.mkdir(parents=True, exist_ok=True)
        out = str(self.workspace / "settlement_types.tif")
        self._log("Rasterizing settlements by place type (Town/Village/Suburb/Hamlet)...")
        rasterize_settlement_types(
            self.settlement_path, out, self.reference_raster,
            place_field=self.place_field, progress_cb=self._progress)
        self._log("  [OK] Settlement type raster: " + out)
        self._log("  Encoding: Town=1 (most restrictive), Village=2, Suburb=3, Hamlet=4")
        return {"settlement_type_raster": out}


# ---------------------------------------------------------------------------
# Distance Raster Worker
# ---------------------------------------------------------------------------
class DistanceRasterWorker(BaseWorker):
    def __init__(self, layer_paths: dict[str, str],
                 reference_raster: str, workspace: str) -> None:
        super().__init__()
        self.layer_paths      = layer_paths
        self.reference_raster = reference_raster
        self.workspace        = Path(workspace)

    def _execute(self) -> dict[str, Any]:
        from raster.raster_processor import euclidean_distance_raster
        self.workspace.mkdir(parents=True, exist_ok=True)
        results = {}
        items = list(self.layer_paths.items())
        for i, (lid, vpath) in enumerate(items):
            name = Path(vpath).stem
            self._log(f"Distance raster: {name}")
            out = str(self.workspace / f"dist_{lid}.tif")
            try:
                euclidean_distance_raster(
                    vpath, out, self.reference_raster,
                    progress_cb=lambda f, _i=i: self._progress((_i + f) / len(items)))
                results[lid] = out
                self._log(f"  [OK] {name}")
            except Exception as e:
                self._log(f"  [ERR] {name}: {e}")
            self._progress((i + 1) / len(items))
        return results


# ---------------------------------------------------------------------------
# Least Cost Path Worker
# ---------------------------------------------------------------------------
class LCPWorker(BaseWorker):
    """Run least cost path analysis using Dijkstra algorithm."""

    def __init__(self, cost_surface_path: str, start: tuple, end: tuple,
                 output_dir: str, prefix: str = "lcp") -> None:
        super().__init__()
        self.cost_surface_path = cost_surface_path
        self.start      = start
        self.end        = end
        self.output_dir = output_dir
        self.prefix     = prefix

    def _execute(self) -> dict[str, Any]:
        from processing.lcp_engine import LCPEngine
        self._log("Loading cost surface for LCP analysis...")
        engine = LCPEngine()
        engine.load_cost_surface(self.cost_surface_path)

        if len(self.start) == 3 and self.start[2] == "rc":
            engine.set_start_rc(self.start[0], self.start[1])
        else:
            engine.set_start_point(self.start[0], self.start[1])

        if len(self.end) == 3 and self.end[2] == "rc":
            engine.set_end_rc(self.end[0], self.end[1])
        else:
            engine.set_end_point(self.end[0], self.end[1])

        self._log("Running Dijkstra 8-connected LCP algorithm...")
        engine.run(progress_cb=lambda f: self._progress(f * 0.85))

        self._log("Exporting LCP outputs...")
        outputs = engine.export_outputs(
            self.output_dir, prefix=self.prefix,
            progress_cb=lambda f: self._progress(0.85 + f * 0.15))
        path_km = engine.path_length_m / 1000
        self._log(f"  [OK] Optimal route length: {path_km:.3f} km")
        return outputs
