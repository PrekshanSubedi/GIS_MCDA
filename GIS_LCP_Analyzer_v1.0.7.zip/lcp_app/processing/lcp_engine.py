"""
Least Cost Path Analysis Engine
=================================
Implements:
  - Accumulated cost surface (Dijkstra 8-connected)
  - Backlink / direction raster
  - Least cost path trace (end → start via backlinks)
  - Output: cost distance raster, backlink raster, path raster,
            shapefile (.shp), KML (.kml)

Building barriers: cells with value >= BARRIER_THRESHOLD are skipped.
"""

import logging
import heapq
import math
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional, Callable, Tuple
import numpy as np

logger = logging.getLogger(__name__)

try:
    import rasterio
    from rasterio.crs import CRS
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False

try:
    import geopandas as gpd
    from shapely.geometry import LineString, Point
    GEOPANDAS_OK = True
except ImportError:
    GEOPANDAS_OK = False

try:
    from pyproj import Transformer
    PYPROJ_OK = True
except ImportError:
    PYPROJ_OK = False

# 8-connected movement: (row_delta, col_delta, distance_multiplier)
DIRECTIONS_8 = [
    (-1,  0, 1.0),
    ( 1,  0, 1.0),
    ( 0,  1, 1.0),
    ( 0, -1, 1.0),
    (-1,  1, math.sqrt(2)),
    (-1, -1, math.sqrt(2)),
    ( 1,  1, math.sqrt(2)),
    ( 1, -1, math.sqrt(2)),
]

DIRECTION_CODES = {
    (-1,  0): 1, ( 1,  0): 2, ( 0,  1): 3, ( 0, -1): 4,
    (-1,  1): 5, (-1, -1): 6, ( 1,  1): 7, ( 1, -1): 8,
}
BACK_DIRECTIONS = {
    1: ( 1,  0), 2: (-1,  0), 3: ( 0, -1), 4: ( 0,  1),
    5: ( 1, -1), 6: ( 1,  1), 7: (-1, -1), 8: (-1,  1),
}

# Cells with cost >= this are treated as absolute barriers
BARRIER_THRESHOLD = 9000.0


class LCPEngine:
    """Least Cost Path engine — Dijkstra on a weighted raster grid."""

    def __init__(self) -> None:
        self.cost_array:  Optional[np.ndarray]  = None
        self.transform    = None
        self.crs          = None
        self.nodata:      float                 = -9999.0
        self.pixel_size:  float                 = 30.0

        self.start_rc:    Optional[Tuple[int, int]] = None
        self.end_rc:      Optional[Tuple[int, int]] = None

        # Outputs
        self.cost_distance: Optional[np.ndarray] = None
        self.backlink:      Optional[np.ndarray] = None
        self.path_mask:     Optional[np.ndarray] = None
        self.path_coords:   list[Tuple[float, float]] = []

    # ------------------------------------------------------------------
    # Load cost surface
    # ------------------------------------------------------------------
    def load_cost_surface(self, path: str) -> None:
        if not RASTERIO_OK:
            raise RuntimeError("Rasterio not installed.")
        with rasterio.open(path) as src:
            self.cost_array = src.read(1).astype(np.float64)
            self.transform  = src.transform
            self.crs        = src.crs
            nd              = src.nodata
            if nd is not None:
                self.nodata = float(nd)
            self.pixel_size = abs(src.transform.a)

        # Convert nodata/nan to inf so Dijkstra skips them
        bad = np.isnan(self.cost_array)
        bad |= (self.cost_array == self.nodata)
        self.cost_array[bad] = np.inf

        # Building barriers (value >= BARRIER_THRESHOLD) → inf
        self.cost_array[self.cost_array >= BARRIER_THRESHOLD] = np.inf

        n_valid   = int(np.sum(np.isfinite(self.cost_array)))
        n_barrier = int(np.sum(np.isinf(self.cost_array)))
        logger.info(
            "Cost surface loaded: shape=%s  pixel=%.1fm  valid=%d  barriers=%d",
            self.cost_array.shape, self.pixel_size, n_valid, n_barrier
        )

    # ------------------------------------------------------------------
    # Coordinate conversion
    # ------------------------------------------------------------------
    def latlon_to_rc(self, lat: float, lon: float, src_crs: str = "EPSG:4326") -> Tuple[int, int]:
        if not PYPROJ_OK:
            raise RuntimeError("pyproj not installed.")
        t = Transformer.from_crs(src_crs, self.crs.to_string(), always_xy=True)
        x, y = t.transform(lon, lat)
        return self._xy_to_rc(x, y)

    def _xy_to_rc(self, x: float, y: float) -> Tuple[int, int]:
        tf  = self.transform
        col = int((x - tf.c) / tf.a)
        row = int((y - tf.f) / tf.e)
        rows, cols = self.cost_array.shape
        row = max(0, min(row, rows - 1))
        col = max(0, min(col, cols - 1))
        return row, col

    def rc_to_xy(self, row: int, col: int) -> Tuple[float, float]:
        tf = self.transform
        x  = tf.c + col * tf.a + tf.a / 2
        y  = tf.f + row * tf.e + tf.e / 2
        return x, y

    def set_start_point(self, lat: float, lon: float, crs: str = "EPSG:4326") -> None:
        self.start_rc = self.latlon_to_rc(lat, lon, crs)
        logger.info("Start: row=%d col=%d (lat=%.5f lon=%.5f)", *self.start_rc, lat, lon)

    def set_end_point(self, lat: float, lon: float, crs: str = "EPSG:4326") -> None:
        self.end_rc = self.latlon_to_rc(lat, lon, crs)
        logger.info("End:   row=%d col=%d (lat=%.5f lon=%.5f)", *self.end_rc, lat, lon)

    def set_start_rc(self, row: int, col: int) -> None:
        self.start_rc = (row, col)

    def set_end_rc(self, row: int, col: int) -> None:
        self.end_rc = (row, col)

    # ------------------------------------------------------------------
    # Validate start/end are passable
    # ------------------------------------------------------------------
    def _snap_to_passable(self, rc: Tuple[int, int], label: str) -> Tuple[int, int]:
        """If the given cell is a barrier, find nearest passable cell."""
        r, c = rc
        rows, cols = self.cost_array.shape
        if np.isfinite(self.cost_array[r, c]):
            return rc
        # Spiral search outward up to 50 pixels
        for radius in range(1, 51):
            for dr in range(-radius, radius + 1):
                for dc in range(-radius, radius + 1):
                    if abs(dr) != radius and abs(dc) != radius:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < rows and 0 <= nc < cols:
                        if np.isfinite(self.cost_array[nr, nc]):
                            logger.info(
                                "%s snapped from (%d,%d) to (%d,%d) — original was barrier",
                                label, r, c, nr, nc
                            )
                            return nr, nc
        logger.warning("%s at (%d,%d): no passable cell found within 50px", label, r, c)
        return rc

    # ------------------------------------------------------------------
    # Dijkstra
    # ------------------------------------------------------------------
    def run(self, progress_cb: Optional[Callable[[float], None]] = None) -> None:
        if self.cost_array is None:
            raise RuntimeError("Load cost surface first.")
        if self.start_rc is None or self.end_rc is None:
            raise RuntimeError("Set start and end points first.")

        # Snap to passable cells
        self.start_rc = self._snap_to_passable(self.start_rc, "Start")
        self.end_rc   = self._snap_to_passable(self.end_rc,   "End")

        logger.info("Dijkstra: start=%s  end=%s", self.start_rc, self.end_rc)
        self._run_dijkstra(progress_cb)
        self._trace_path()
        logger.info("LCP done. Path cells: %d  Length: %.1fm",
                    len(self.path_coords), self.path_length_m)

    def _run_dijkstra(self, progress_cb=None) -> None:
        cost      = self.cost_array
        rows, cols = cost.shape
        INF       = np.inf

        dist     = np.full((rows, cols), INF, dtype=np.float64)
        backlink = np.zeros((rows, cols), dtype=np.uint8)
        visited  = np.zeros((rows, cols), dtype=bool)

        sr, sc = self.start_rc
        er, ec = self.end_rc
        dist[sr, sc] = 0.0

        heap      = [(0.0, sr, sc)]
        processed = 0
        total     = rows * cols

        while heap:
            acc, r, c = heapq.heappop(heap)
            if visited[r, c]:
                continue
            visited[r, c] = True
            processed += 1

            if progress_cb and processed % 50_000 == 0:
                progress_cb(min(0.88, processed / total))

            if r == er and c == ec:
                logger.info("Destination reached after %d steps", processed)
                break

            curr_cost = cost[r, c]
            if curr_cost == INF:
                continue

            for dr, dc, dmult in DIRECTIONS_8:
                nr, nc = r + dr, c + dc
                if not (0 <= nr < rows and 0 <= nc < cols):
                    continue
                if visited[nr, nc]:
                    continue
                nb_cost = cost[nr, nc]
                if nb_cost == INF:
                    continue
                # Cost = average of current + neighbour × pixel_size × direction_mult
                step = ((curr_cost + nb_cost) / 2.0) * dmult * self.pixel_size
                new_d = acc + step
                if new_d < dist[nr, nc]:
                    dist[nr, nc] = new_d
                    backlink[nr, nc] = DIRECTION_CODES[(dr, dc)]
                    heapq.heappush(heap, (new_d, nr, nc))

        end_cost = float(dist[er, ec])
        if end_cost == INF:
            raise RuntimeError(
                f"No passable path found from {self.start_rc} to {self.end_rc}. "
                "Check that start/end points are outside building barriers and within the cost surface extent."
            )

        self.cost_distance = np.where(dist == INF, -9999, dist).astype(np.float32)
        self.backlink      = backlink
        logger.info("Dijkstra complete. End accumulated cost = %.2f", end_cost)

    def _trace_path(self) -> None:
        rows, cols  = self.cost_array.shape
        path_mask   = np.zeros((rows, cols), dtype=np.uint8)
        coords      = []

        r, c        = self.end_rc
        sr, sc      = self.start_rc
        max_steps   = rows * cols + 10

        for _ in range(max_steps):
            if r == sr and c == sc:
                break
            path_mask[r, c] = 1
            coords.append(self.rc_to_xy(r, c))
            code = int(self.backlink[r, c])
            if code == 0:
                logger.warning("Backlink=0 at (%d,%d) — path may be truncated", r, c)
                break
            dr, dc = BACK_DIRECTIONS[code]
            r, c   = r + dr, c + dc

        # Add start cell
        path_mask[sr, sc] = 1
        coords.append(self.rc_to_xy(sr, sc))

        self.path_mask   = path_mask
        self.path_coords = list(reversed(coords))

    # ------------------------------------------------------------------
    # Export outputs
    # ------------------------------------------------------------------
    def export_outputs(
        self,
        output_dir: str,
        prefix: str = "lcp",
        progress_cb: Optional[Callable[[float], None]] = None,
    ) -> dict[str, str]:
        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        outputs: dict[str, str] = {}

        if not RASTERIO_OK:
            raise RuntimeError("Rasterio required for export.")

        meta_base = {
            "driver":    "GTiff",
            "crs":       self.crs,
            "transform": self.transform,
            "width":     self.cost_array.shape[1],
            "height":    self.cost_array.shape[0],
            "count":     1,
            "compress":  "lzw",
        }

        # 1. Cost distance raster
        if self.cost_distance is not None:
            p = str(out_dir / f"{prefix}_cost_distance.tif")
            with rasterio.open(p, "w", **{**meta_base, "dtype": "float32", "nodata": -9999}) as dst:
                dst.write(self.cost_distance, 1)
            outputs["cost_distance"] = p
            logger.info("Cost distance raster: %s", p)

        if progress_cb: progress_cb(0.25)

        # 2. Backlink raster
        if self.backlink is not None:
            p = str(out_dir / f"{prefix}_backlink.tif")
            with rasterio.open(p, "w", **{**meta_base, "dtype": "uint8", "nodata": 0}) as dst:
                dst.write(self.backlink, 1)
            outputs["backlink"] = p
            logger.info("Backlink raster: %s", p)

        if progress_cb: progress_cb(0.50)

        # 3. Path raster
        if self.path_mask is not None:
            p = str(out_dir / f"{prefix}_path_raster.tif")
            with rasterio.open(p, "w", **{**meta_base, "dtype": "uint8", "nodata": 0}) as dst:
                dst.write(self.path_mask, 1)
            outputs["path_raster"] = p
            logger.info("Path raster: %s", p)

        if progress_cb: progress_cb(0.70)

        # 4. Shapefile
        if self.path_coords and len(self.path_coords) >= 2 and GEOPANDAS_OK:
            shp_path = self._export_shapefile(out_dir, prefix)
            if shp_path:
                outputs["shapefile"] = shp_path

        if progress_cb: progress_cb(0.85)

        # 5. KML (manual writer — no fiona driver dependency)
        if self.path_coords and len(self.path_coords) >= 2:
            kml_path = self._export_kml(out_dir, prefix)
            if kml_path:
                outputs["kml"] = kml_path

        if progress_cb: progress_cb(1.0)
        return outputs

    def _export_shapefile(self, out_dir: Path, prefix: str) -> Optional[str]:
        """Export LCP as a polyline shapefile with attributes."""
        try:
            line     = LineString(self.path_coords)
            crs_str  = self.crs.to_string()
            length_m = self.path_length_m

            gdf = gpd.GeoDataFrame(
                {
                    "id":        [1],
                    "name":      ["Optimal LCP Route"],
                    "length_m":  [round(length_m, 2)],
                    "length_km": [round(length_m / 1000, 4)],
                    "method":    ["Dijkstra-8conn"],
                    "ref":       ["GIS-TL-DS-2026-001"],
                },
                geometry=[line],
                crs=crs_str,
            )

            shp_path = str(out_dir / f"{prefix}_optimal_route.shp")
            gdf.to_file(shp_path)
            logger.info("Shapefile: %s  length=%.1fm", shp_path, length_m)
            return shp_path
        except Exception as e:
            logger.error("Shapefile export failed: %s", e, exc_info=True)
            return None

    def _export_kml(self, out_dir: Path, prefix: str) -> Optional[str]:
        """
        Export LCP as KML using a manual XML writer.
        Avoids fiona KML driver issues on Windows.
        Reprojects coordinates to WGS84 (EPSG:4326) for KML spec compliance.
        """
        try:
            # Reproject path coords to WGS84
            if PYPROJ_OK and self.crs:
                t = Transformer.from_crs(
                    self.crs.to_string(), "EPSG:4326", always_xy=True
                )
                wgs_coords = [t.transform(x, y) for x, y in self.path_coords]
            else:
                wgs_coords = self.path_coords  # already geographic

            length_m  = self.path_length_m
            coord_str = " ".join(f"{lon:.7f},{lat:.7f},0" for lon, lat in wgs_coords)

            kml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>GIS LCP Analyzer — Optimal Route</name>
    <description>Least Cost Path — GIS-TL-DS-2026-001</description>
    <Style id="lcpStyle">
      <LineStyle>
        <color>ff00ffff</color>
        <width>3</width>
      </LineStyle>
    </Style>
    <Placemark>
      <name>Optimal LCP Route</name>
      <description>
        Method: Dijkstra 8-connected
        Length: {length_m:.1f} m ({length_m/1000:.3f} km)
        Reference: GIS-TL-DS-2026-001
      </description>
      <styleUrl>#lcpStyle</styleUrl>
      <LineString>
        <tessellate>1</tessellate>
        <altitudeMode>clampToGround</altitudeMode>
        <coordinates>{coord_str}</coordinates>
      </LineString>
    </Placemark>
    <Placemark>
      <name>Start Point</name>
      <Point>
        <coordinates>{wgs_coords[0][0]:.7f},{wgs_coords[0][1]:.7f},0</coordinates>
      </Point>
    </Placemark>
    <Placemark>
      <name>End Point</name>
      <Point>
        <coordinates>{wgs_coords[-1][0]:.7f},{wgs_coords[-1][1]:.7f},0</coordinates>
      </Point>
    </Placemark>
  </Document>
</kml>"""

            kml_path = str(out_dir / f"{prefix}_optimal_route.kml")
            with open(kml_path, "w", encoding="utf-8") as f:
                f.write(kml_content)
            logger.info("KML: %s  coords=%d", kml_path, len(wgs_coords))
            return kml_path
        except Exception as e:
            logger.error("KML export failed: %s", e, exc_info=True)
            return None

    @property
    def path_length_m(self) -> float:
        if not self.path_coords or len(self.path_coords) < 2:
            return 0.0
        total = 0.0
        for i in range(1, len(self.path_coords)):
            dx = self.path_coords[i][0] - self.path_coords[i-1][0]
            dy = self.path_coords[i][1] - self.path_coords[i-1][1]
            total += math.sqrt(dx*dx + dy*dy)
        return total
