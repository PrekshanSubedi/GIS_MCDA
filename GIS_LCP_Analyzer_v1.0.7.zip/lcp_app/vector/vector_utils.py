"""
Vector Processing Utilities
=============================
Helper functions for vector data operations:
  - CRS detection
  - Buffer creation
  - Geometry validation
  - Conversion utilities
"""

import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def get_vector_info(path: str) -> dict:
    """Return metadata for a vector file."""
    info: dict = {}
    try:
        import geopandas as gpd
        gdf = gpd.read_file(path)
        info["crs"] = gdf.crs.to_string() if gdf.crs else "Unknown"
        info["feature_count"] = len(gdf)
        if len(gdf) > 0:
            info["geometry_type"] = gdf.geometry.iloc[0].geom_type
        bounds = gdf.total_bounds
        info["extent"] = tuple(bounds)
        info["columns"] = list(gdf.columns)
    except Exception as e:
        logger.error("get_vector_info failed for %s: %s", path, e)
    return info


def buffer_vector(
    input_path: str,
    output_path: str,
    buffer_m: float,
    dissolve: bool = True,
) -> None:
    """
    Buffer a vector layer by a given distance in metres.
    Input must be in a projected CRS (metres).
    """
    try:
        import geopandas as gpd
        gdf = gpd.read_file(input_path)
        gdf["geometry"] = gdf.geometry.buffer(buffer_m)
        if dissolve:
            gdf = gdf.dissolve()
        gdf.to_file(output_path)
        logger.info("Buffered vector saved to %s (buffer=%.1fm)", output_path, buffer_m)
    except Exception as e:
        logger.error("buffer_vector failed: %s", e)
        raise


def validate_geometry(path: str) -> tuple[bool, list[str]]:
    """
    Validate all geometries in a vector file.
    Returns (is_valid, list_of_issues).
    """
    issues = []
    try:
        import geopandas as gpd
        from shapely.validation import explain_validity
        gdf = gpd.read_file(path)
        for i, geom in enumerate(gdf.geometry):
            if geom is None or geom.is_empty:
                issues.append(f"Feature {i}: null/empty geometry")
            elif not geom.is_valid:
                issues.append(f"Feature {i}: {explain_validity(geom)}")
    except Exception as e:
        issues.append(str(e))
    return len(issues) == 0, issues


def coords_to_point_shapefile(
    lat: float,
    lon: float,
    output_path: str,
    crs: str = "EPSG:4326",
) -> None:
    """Create a single-point shapefile from lat/lon coordinates."""
    try:
        import geopandas as gpd
        from shapely.geometry import Point
        gdf = gpd.GeoDataFrame(
            {"id": [1], "lat": [lat], "lon": [lon]},
            geometry=[Point(lon, lat)],
            crs="EPSG:4326",
        )
        if crs != "EPSG:4326":
            gdf = gdf.to_crs(crs)
        gdf.to_file(output_path)
        logger.info("Point shapefile created: %s", output_path)
    except Exception as e:
        logger.error("coords_to_point_shapefile failed: %s", e)
        raise
