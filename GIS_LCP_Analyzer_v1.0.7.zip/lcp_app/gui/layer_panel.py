"""
Layer Panel Widget
==================
Left-panel widget showing loaded GIS layers with controls for:
  - Enable/disable
  - Visibility toggle
  - Role assignment
  - Weight display
  - Remove
  - Properties popup
"""

import logging
from pathlib import Path
from typing import Optional, Callable

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QCheckBox, QComboBox,
    QDoubleSpinBox, QMenu, QAction, QSizePolicy, QToolButton,
    QFrame, QAbstractItemView, QHeaderView,
)
from PyQt5.QtCore import Qt, pyqtSignal, QSize
from PyQt5.QtGui import QColor, QBrush, QFont, QIcon

from core.layer_model import LayerInfo, LayerType, LayerRole

logger = logging.getLogger(__name__)

# Role choices for the dropdown in each row
ROLE_CHOICES = [r.value for r in LayerRole]


class LayerItemWidget(QFrame):
    """Compact widget representing one layer row."""

    visibility_changed = pyqtSignal(str, bool)    # layer_id, visible
    enabled_changed = pyqtSignal(str, bool)        # layer_id, enabled
    remove_requested = pyqtSignal(str)             # layer_id
    role_changed = pyqtSignal(str, str)            # layer_id, role_value

    def __init__(self, layer: LayerInfo, parent=None) -> None:
        super().__init__(parent)
        self.layer = layer
        self._build_ui()

    def _build_ui(self) -> None:
        self.setFrameShape(QFrame.StyledPanel)
        self.setObjectName("layerItem")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 3, 4, 3)
        layout.setSpacing(4)

        # Colour swatch
        swatch = QLabel()
        swatch.setFixedSize(14, 14)
        r, g, b = self.layer.color
        swatch.setStyleSheet(
            f"background-color: rgb({r},{g},{b}); border-radius: 3px; border: 1px solid #555;"
        )
        layout.addWidget(swatch)

        # Visibility checkbox
        self.vis_cb = QCheckBox()
        self.vis_cb.setChecked(self.layer.visible)
        self.vis_cb.setToolTip("Toggle visibility")
        self.vis_cb.setFixedWidth(20)
        self.vis_cb.stateChanged.connect(
            lambda s: self.visibility_changed.emit(self.layer.layer_id, bool(s))
        )
        layout.addWidget(self.vis_cb)

        # Layer name
        name_lbl = QLabel(self.layer.display_name[:28])
        name_lbl.setToolTip(f"{self.layer.file_path}\nCRS: {self.layer.short_crs()}")
        name_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.addWidget(name_lbl)

        # Type badge
        type_map = {
            LayerType.RASTER: ("R", "#f38ba8"),
            LayerType.VECTOR_POLYGON: ("P", "#a6e3a1"),
            LayerType.VECTOR_POINT: ("Pt", "#fab387"),
            LayerType.VECTOR_LINE: ("L", "#89dceb"),
        }
        badge_txt, badge_col = type_map.get(self.layer.layer_type, ("?", "#585b70"))
        badge = QLabel(badge_txt)
        badge.setFixedWidth(22)
        badge.setAlignment(Qt.AlignCenter)
        badge.setStyleSheet(
            f"background-color: {badge_col}; color: #1e1e2e; "
            f"border-radius: 3px; font-size: 10px; font-weight: bold;"
        )
        layout.addWidget(badge)

        # Remove button
        rm_btn = QToolButton()
        rm_btn.setText("✕")
        rm_btn.setFixedSize(20, 20)
        rm_btn.setToolTip("Remove layer")
        rm_btn.clicked.connect(lambda: self.remove_requested.emit(self.layer.layer_id))
        layout.addWidget(rm_btn)


class LayerPanel(QWidget):
    """
    Left panel widget for GIS layer management.

    Signals
    -------
    layer_selected : str   → layer_id
    layer_removed  : str   → layer_id
    layer_visibility_changed : (str, bool)
    """

    layer_selected = pyqtSignal(str)
    layer_removed = pyqtSignal(str)
    layer_visibility_changed = pyqtSignal(str, bool)
    role_changed = pyqtSignal(str, str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._layers: dict[str, LayerInfo] = {}
        self._items: dict[str, QTreeWidgetItem] = {}
        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # Header
        hdr = QLabel("📂  Layers")
        hdr.setObjectName("title")
        layout.addWidget(hdr)

        # Tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Layer", "Role", "CRS", "W"])
        self.tree.setAlternatingRowColors(True)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.tree.header().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.tree.itemSelectionChanged.connect(self._on_selection_changed)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)
        layout.addWidget(self.tree)

        # Bottom buttons
        btn_row = QHBoxLayout()
        self.clear_btn = QPushButton("Clear All")
        self.clear_btn.setFixedHeight(26)
        self.clear_btn.clicked.connect(self.clear_all)
        btn_row.addWidget(self.clear_btn)
        layout.addLayout(btn_row)

    # ------------------------------------------------------------------
    def add_layer(self, layer: LayerInfo) -> None:
        """Add a layer to the panel."""
        self._layers[layer.layer_id] = layer
        item = QTreeWidgetItem()
        item.setData(0, Qt.UserRole, layer.layer_id)

        # Col 0: name + visibility checkbox (handled via flags)
        item.setText(0, layer.display_name)
        item.setCheckState(0, Qt.Checked if layer.visible else Qt.Unchecked)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable)

        # Color indicator
        r, g, b = layer.color
        item.setForeground(0, QBrush(QColor(r, g, b)))

        # Col 1: Role (combobox set via setItemWidget)
        item.setText(1, layer.role.value)

        # Col 2: CRS short
        item.setText(2, layer.short_crs())

        # Col 3: Weight
        item.setText(3, f"{layer.weight:.3f}")

        self.tree.addTopLevelItem(item)
        self._items[layer.layer_id] = item

        # Embed role combo
        role_combo = QComboBox()
        role_combo.addItems(ROLE_CHOICES)
        role_combo.setCurrentText(layer.role.value)
        role_combo.setFixedHeight(22)
        role_combo.currentTextChanged.connect(
            lambda v, lid=layer.layer_id: self._on_role_changed(lid, v)
        )
        self.tree.setItemWidget(item, 1, role_combo)

    def update_layer_weight(self, layer_id: str, weight: float) -> None:
        """Update the displayed weight for a layer."""
        item = self._items.get(layer_id)
        if item:
            item.setText(3, f"{weight:.3f}")
        if layer_id in self._layers:
            self._layers[layer_id].weight = weight

    def remove_layer(self, layer_id: str) -> None:
        """Remove a layer from the panel."""
        item = self._items.pop(layer_id, None)
        if item:
            idx = self.tree.indexOfTopLevelItem(item)
            if idx >= 0:
                self.tree.takeTopLevelItem(idx)
        self._layers.pop(layer_id, None)
        self.layer_removed.emit(layer_id)

    def clear_all(self) -> None:
        self.tree.clear()
        self._layers.clear()
        self._items.clear()

    def get_layer(self, layer_id: str) -> Optional[LayerInfo]:
        return self._layers.get(layer_id)

    def all_layers(self) -> list[LayerInfo]:
        return list(self._layers.values())

    # ------------------------------------------------------------------
    def _on_selection_changed(self) -> None:
        items = self.tree.selectedItems()
        if items:
            lid = items[0].data(0, Qt.UserRole)
            if lid:
                self.layer_selected.emit(lid)

    def _on_role_changed(self, layer_id: str, role_value: str) -> None:
        lyr = self._layers.get(layer_id)
        if lyr:
            try:
                lyr.role = LayerRole(role_value)
            except ValueError:
                pass
        self.role_changed.emit(layer_id, role_value)

    def _show_context_menu(self, pos) -> None:
        item = self.tree.itemAt(pos)
        if not item:
            return
        lid = item.data(0, Qt.UserRole)
        menu = QMenu(self)
        remove_act = QAction("Remove Layer", self)
        remove_act.triggered.connect(lambda: self.remove_layer(lid))
        menu.addAction(remove_act)
        menu.exec_(self.tree.viewport().mapToGlobal(pos))
