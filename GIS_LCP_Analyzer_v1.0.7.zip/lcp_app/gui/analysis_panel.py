"""
Analysis Panel Widget
======================
Right-panel containing all analysis tool tabs:
  1. Data Input
  2. CRS / Reproject
  3. DEM Processing
  4. Rasterization
  5. Reclassification
  6. AHP Weights
  7. Weighted Overlay
  8. Least Cost Path
  9. Output Settings
"""

import logging
from pathlib import Path
from typing import Optional, Callable

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QLabel,
    QPushButton, QFileDialog, QLineEdit, QDoubleSpinBox,
    QSpinBox, QGroupBox, QComboBox, QCheckBox, QGridLayout,
    QTableWidget, QTableWidgetItem, QAbstractItemView,
    QHeaderView, QScrollArea, QFrame, QSizePolicy, QMessageBox,
    QListWidget, QListWidgetItem, QSlider,
)
from PyQt5.QtCore import Qt, pyqtSignal

logger = logging.getLogger(__name__)

# Reclassification default tables (from GIS-TL-DS-2026-001)
DEFAULT_SLOPE_RECLASS = [
    {"min": 0,  "max": 5,  "output": 1, "label": "0–5° (Flat)"},
    {"min": 5,  "max": 15, "output": 3, "label": "5–15° (Gentle)"},
    {"min": 15, "max": 25, "output": 5, "label": "15–25° (Moderate)"},
    {"min": 25, "max": 35, "output": 7, "label": "25–35° (Steep)"},
    {"min": 35, "max": 999,"output": 9, "label": ">35° (Very Steep)"},
]
DEFAULT_TRI_RECLASS = [
    {"min": 0,   "max": 20,  "output": 1, "label": "0–20 (Level)"},
    {"min": 20,  "max": 60,  "output": 3, "label": "20–60 (Slight)"},
    {"min": 60,  "max": 120, "output": 5, "label": "60–120 (Moderate)"},
    {"min": 120, "max": 200, "output": 7, "label": "120–200 (High)"},
    {"min": 200, "max": 9999,"output": 9, "label": ">200 (Extreme)"},
]
DEFAULT_SETTLEMENT_RECLASS = [
    # Place-type based: cost = 1 (highest priority to avoid) for Town, scaling up
    # Town = most important to avoid (cost 1 = cheapest to route NEAR, but for LCP
    # we want to AVOID settlements, so cost 9 = most constrained near settlements)
    # Priority order: Town > Village > Suburb > Hamlet (most to least restrictive)
    {"min": 1, "max": 1, "output": 9, "label": "1 = Town (most restrictive)"},
    {"min": 2, "max": 2, "output": 7, "label": "2 = Village"},
    {"min": 3, "max": 3, "output": 5, "label": "3 = Suburb"},
    {"min": 4, "max": 4, "output": 3, "label": "4 = Hamlet (least restrictive)"},
]

# Settlement place-type encoding used for rasterization
SETTLEMENT_TYPE_MAP = {
    "town":   1,
    "village": 2,
    "suburb":  3,
    "hamlet":  4,
}

DEFAULT_SETTLEMENT_DISTANCE_RECLASS = [
    {"min": 0,    "max": 500,  "output": 9, "label": "<500m"},
    {"min": 500,  "max": 1000, "output": 7, "label": "500-1000m"},
    {"min": 1000, "max": 2000, "output": 4, "label": "1000-2000m"},
    {"min": 2000, "max": 99999,"output": 1, "label": ">2000m"},
]
DEFAULT_WATERWAY_RECLASS = [
    {"min": 0,   "max": 50,  "output": 9, "label": "<50m"},
    {"min": 50,  "max": 150, "output": 7, "label": "50–150m"},
    {"min": 150, "max": 300, "output": 4, "label": "150–300m"},
    {"min": 300, "max": 99999,"output": 1, "label": ">300m"},
]
DEFAULT_ROAD_RECLASS = [
    {"min": 0,    "max": 100,  "output": 1, "label": "<100m"},
    {"min": 100,  "max": 500,  "output": 2, "label": "100–500m"},
    {"min": 500,  "max": 1000, "output": 4, "label": "500–1000m"},
    {"min": 1000, "max": 2000, "output": 6, "label": "1000–2000m"},
    {"min": 2000, "max": 99999,"output": 9, "label": ">2000m"},
]
DEFAULT_LULC_RECLASS = [
    {"min": 1, "max": 1, "output": 9, "label": "1 Waterbody"},
    {"min": 2, "max": 2, "output": 9, "label": "2 Glacier"},
    {"min": 3, "max": 3, "output": 9, "label": "3 Snow"},
    {"min": 4, "max": 4, "output": 5, "label": "4 Forest"},
    {"min": 5, "max": 5, "output": 7, "label": "5 Riverbed"},
    {"min": 6, "max": 6, "output": 9, "label": "6 Built-up"},
    {"min": 7, "max": 7, "output": 2, "label": "7 Cropland"},
    {"min": 8, "max": 8, "output": 3, "label": "8 Bare Soil"},
    {"min": 9, "max": 9, "output": 4, "label": "9 Bare Rock"},
    {"min": 10,"max": 10,"output": 1, "label": "10 Grassland"},
    {"min": 11,"max": 11,"output": 3, "label": "11 Other Wooded"},
]
DEFAULT_BUILDING_RECLASS = [
    {"min": 0,   "max": 50,  "output": 9, "label": "<50m (Hard constraint)"},
    {"min": 50,  "max": 100, "output": 8, "label": "50–100m"},
    {"min": 100, "max": 200, "output": 6, "label": "100–200m"},
    {"min": 200, "max": 500, "output": 3, "label": "200–500m"},
    {"min": 500, "max": 99999,"output": 1, "label": ">500m"},
]

CRS_PRESETS = [
    "EPSG:32645",  # UTM 45N — Nepal
    "EPSG:32644",  # UTM 44N
    "EPSG:32646",  # UTM 46N
    "EPSG:4326",   # WGS84
    "EPSG:3857",   # Web Mercator
    "EPSG:32643",  # UTM 43N
]


class AnalysisPanel(QWidget):
    """Right-side analysis tools panel."""

    # Emitted when user clicks a run button
    run_reproject = pyqtSignal(str)               # target_crs
    run_dem_derivatives = pyqtSignal(str)          # dem_path
    run_distance_rasters = pyqtSignal(object)      # {layer_id: path}
    run_building_constraint = pyqtSignal(str, float)  # building_path, buffer_m
    run_reclassify = pyqtSignal(object)            # list of reclass configs
    run_weighted_overlay = pyqtSignal()
    run_lcp = pyqtSignal(object, object)           # start (lat,lon), end (lat,lon)
    load_layer = pyqtSignal(str, str)              # file_path, role_hint
    display_raster = pyqtSignal(str)               # raster path to display

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._build_ui()

    # ==================================================================
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        self.tabs = QTabWidget()
        self.tabs.setTabPosition(QTabWidget.North)

        self.tabs.addTab(self._build_input_tab(), "📂 Input")
        self.tabs.addTab(self._build_crs_tab(), "🌐 CRS")
        self.tabs.addTab(self._build_dem_tab(), "⛰ DEM")
        self.tabs.addTab(self._build_reclass_tab(), "🔄 Reclass")
        self.tabs.addTab(self._build_overlay_tab(), "🗺 Overlay")
        self.tabs.addTab(self._build_lcp_tab(), "🛤 LCP")
        self.tabs.addTab(self._build_output_tab(), "💾 Output")

        layout.addWidget(self.tabs)

    # ==================================================================
    # 1. INPUT TAB
    # ==================================================================
    def _build_input_tab(self) -> QWidget:
        w = QScrollArea()
        w.setWidgetResizable(True)
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setSpacing(6)

        lbl = QLabel("Load Dataset Layers")
        lbl.setObjectName("title")
        layout.addWidget(lbl)

        # Each dataset button
        datasets = [
            ("Buildings (Polygon)", "Buildings"),
            ("Settlements (Points)", "Settlements"),
            ("DEM Raster", "DEM"),
            ("Land Use / Land Cover", "Land Use/Land Cover"),
            ("Waterways (Lines)", "Waterways"),
            ("Roads (Lines)", "Roads"),
            ("Study Corridor (Polygon)", "Study Corridor"),
            ("Start Point Shapefile", "Start Point"),
            ("End Point Shapefile", "End Point"),
            ("Additional Layer…", "Auxiliary"),
        ]
        for label, role in datasets:
            row = QHBoxLayout()
            btn = QPushButton(f"  {label}")
            btn.setFixedHeight(30)
            btn.clicked.connect(lambda _, l=label, r=role: self._browse_layer(r))
            row.addWidget(btn)
            layout.addLayout(row)

        # Workflow guide
        guide = QLabel(
            "Workflow Order:\n"
            "1. Load all layers above\n"
            "2. Set CRS (CRS tab)\n"
            "3. Click RUN FULL PIPELINE\n"
            "   (or run steps 1-7 manually)\n"
            "4. Review cost surface on map\n"
            "5. Set start/end, run LCP"
        )
        guide.setObjectName("subtitle")
        guide.setWordWrap(True)
        guide.setStyleSheet(
            "border: 1px solid #45475a; border-radius:4px; padding:6px; "
            "background:#181825; color:#a6e3a1;"
        )
        layout.addWidget(guide)

        layout.addStretch()
        w.setWidget(inner)
        return w

    def _browse_layer(self, role: str) -> None:
        if role == "DEM" or "Raster" in role or "Land Use" in role:
            filt = "Raster Files (*.tif *.tiff *.img *.asc);;All Files (*)"
        else:
            filt = "Vector Files (*.shp *.gpkg *.geojson *.kml);;All Files (*)"
        path, _ = QFileDialog.getOpenFileName(self, f"Load {role}", "", filt)
        if path:
            self.load_layer.emit(path, role)

    # ==================================================================
    # 2. CRS TAB
    # ==================================================================
    def _build_crs_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(8)

        layout.addWidget(QLabel("Target Coordinate Reference System"))

        self.crs_combo = QComboBox()
        self.crs_combo.addItems(CRS_PRESETS)
        self.crs_combo.setEditable(True)
        self.crs_combo.setToolTip("Enter EPSG code or WKT string")
        layout.addWidget(self.crs_combo)

        info = QLabel("EPSG:32645 = WGS84 / UTM Zone 45N (Nepal region)\n"
                      "All loaded layers will be reprojected to this CRS.")
        info.setObjectName("subtitle")
        info.setWordWrap(True)
        layout.addWidget(info)

        btn = QPushButton("Reproject All Layers")
        btn.setObjectName("primary")
        btn.clicked.connect(lambda: self.run_reproject.emit(self.crs_combo.currentText()))
        layout.addWidget(btn)

        layout.addStretch()
        return w

    def get_target_crs(self) -> str:
        return self.crs_combo.currentText() if hasattr(self, "crs_combo") else "EPSG:32645"

    # ==================================================================
    # 3. DEM TAB
    # ==================================================================
    def _build_dem_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(8)

        layout.addWidget(QLabel("DEM Derivatives"))

        # DEM path selector
        dem_row = QHBoxLayout()
        dem_row.addWidget(QLabel("DEM:"))
        self.dem_path_edit = QLineEdit()
        self.dem_path_edit.setPlaceholderText("Select DEM raster…")
        dem_row.addWidget(self.dem_path_edit)
        dem_browse = QPushButton("…")
        dem_browse.setFixedWidth(32)
        dem_browse.clicked.connect(self._browse_dem)
        dem_row.addWidget(dem_browse)
        layout.addLayout(dem_row)

        grp = QGroupBox("Outputs to Generate")
        grp_layout = QVBoxLayout(grp)
        self.slope_cb = QCheckBox("Slope (degrees)")
        self.slope_cb.setChecked(True)
        self.tri_cb = QCheckBox("Terrain Ruggedness Index (TRI)")
        self.tri_cb.setChecked(True)
        grp_layout.addWidget(self.slope_cb)
        grp_layout.addWidget(self.tri_cb)
        layout.addWidget(grp)

        # Building buffer
        buf_grp = QGroupBox("Building Buffer (Hard Constraint)")
        buf_layout = QGridLayout(buf_grp)
        buf_layout.addWidget(QLabel("Buffer radius (m):"), 0, 0)
        self.buffer_spin = QDoubleSpinBox()
        self.buffer_spin.setRange(0, 500)
        self.buffer_spin.setValue(20)
        self.buffer_spin.setSuffix(" m")
        buf_layout.addWidget(self.buffer_spin, 0, 1)
        layout.addWidget(buf_grp)

        btn = QPushButton("Generate DEM Derivatives")
        btn.setObjectName("primary")
        btn.clicked.connect(self._run_dem)
        layout.addWidget(btn)

        layout.addStretch()
        return w

    def _browse_dem(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select DEM", "", "Raster (*.tif *.tiff *.img);;All (*)")
        if path:
            self.dem_path_edit.setText(path)

    def _run_dem(self) -> None:
        path = self.dem_path_edit.text().strip()
        if not path:
            QMessageBox.warning(self, "DEM Required", "Please select a DEM raster.")
            return
        self.run_dem_derivatives.emit(path)

    def get_building_buffer(self) -> float:
        return self.buffer_spin.value() if hasattr(self, "buffer_spin") else 20.0

    # ==================================================================
    # 4. RECLASS TAB
    # ==================================================================
    def _build_reclass_tab(self) -> QWidget:
        w = QScrollArea()
        w.setWidgetResizable(True)
        inner = QWidget()
        layout = QVBoxLayout(inner)
        layout.setSpacing(6)

        layout.addWidget(QLabel("Reclassification Tables (Cost 1=Best, 9=Worst)"))

        self._reclass_tables = {}
        tables_def = [
            ("Slope", DEFAULT_SLOPE_RECLASS),
            ("TRI", DEFAULT_TRI_RECLASS),
            ("Settlement Type", DEFAULT_SETTLEMENT_RECLASS),
            ("Settlement Distance", DEFAULT_SETTLEMENT_DISTANCE_RECLASS),
            ("Waterway Distance", DEFAULT_WATERWAY_RECLASS),
            ("Road Distance", DEFAULT_ROAD_RECLASS),
            ("LULC", DEFAULT_LULC_RECLASS),
            ("Building Distance", DEFAULT_BUILDING_RECLASS),
        ]
        for name, default_table in tables_def:
            grp = QGroupBox(name)
            grp_layout = QVBoxLayout(grp)
            tbl = QTableWidget(len(default_table), 4)
            tbl.setHorizontalHeaderLabels(["Min", "Max", "Cost (1–9)", "Label"])
            tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
            tbl.setFixedHeight(min(len(default_table) * 28 + 35, 220))
            for i, row in enumerate(default_table):
                tbl.setItem(i, 0, QTableWidgetItem(str(row["min"])))
                tbl.setItem(i, 1, QTableWidgetItem(str(row["max"])))
                tbl.setItem(i, 2, QTableWidgetItem(str(row["output"])))
                tbl.setItem(i, 3, QTableWidgetItem(row.get("label", "")))
            grp_layout.addWidget(tbl)
            layout.addWidget(grp)
            self._reclass_tables[name] = tbl

        run_btn = QPushButton("Apply Reclassification")
        run_btn.setObjectName("primary")
        run_btn.clicked.connect(self._run_reclass)
        layout.addWidget(run_btn)

        layout.addStretch()
        w.setWidget(inner)
        return w

    def _run_reclass(self) -> None:
        configs = self.get_reclass_configs()
        self.run_reclassify.emit(configs)

    def get_reclass_configs(self) -> list[dict]:
        """Extract current reclass tables as list of dicts."""
        configs = []
        for name, tbl in self._reclass_tables.items():
            rows = []
            for r in range(tbl.rowCount()):
                try:
                    mn = float(tbl.item(r, 0).text())
                    mx = float(tbl.item(r, 1).text())
                    cost = float(tbl.item(r, 2).text())
                    rows.append({"min": mn, "max": mx, "output": cost})
                except Exception:
                    pass
            configs.append({"name": name, "table": rows})
        return configs

    # ==================================================================
    # 5. WEIGHTED OVERLAY TAB
    # ==================================================================
    def _build_overlay_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(8)

        layout.addWidget(QLabel("Weighted Linear Combination (WLC)"))

        info = QLabel(
            "AHP weights are loaded from the AHP tab.\n"
            "All reclassified layers must be available before running."
        )
        info.setWordWrap(True)
        info.setObjectName("subtitle")
        layout.addWidget(info)

        # Weight display (read-only)
        self.weight_display = QTableWidget(0, 2)
        self.weight_display.setHorizontalHeaderLabels(["Criterion", "Weight"])
        self.weight_display.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.weight_display.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.weight_display.setFixedHeight(200)
        layout.addWidget(self.weight_display)

        self.constraint_cb = QCheckBox("Apply building constraint mask (absolute barriers)")
        self.constraint_cb.setChecked(True)
        layout.addWidget(self.constraint_cb)

        btn = QPushButton("Run Weighted Overlay")
        btn.setObjectName("primary")
        btn.clicked.connect(self.run_weighted_overlay.emit)
        layout.addWidget(btn)

        layout.addStretch()
        return w

    def update_weights_display(self, weights: dict) -> None:
        """Update the weight table from AHP results."""
        self.weight_display.setRowCount(len(weights))
        for i, (k, v) in enumerate(weights.items()):
            self.weight_display.setItem(i, 0, QTableWidgetItem(k))
            self.weight_display.setItem(i, 1, QTableWidgetItem(f"{v:.4f}"))

    def use_constraint_mask(self) -> bool:
        return self.constraint_cb.isChecked() if hasattr(self, "constraint_cb") else True

    # ==================================================================
    # 6. LCP TAB
    # ==================================================================
    def _build_lcp_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(8)

        layout.addWidget(QLabel("Least Cost Path Analysis"))

        # Cost surface selector
        cs_row = QHBoxLayout()
        cs_row.addWidget(QLabel("Cost Surface:"))
        self.cs_edit = QLineEdit()
        self.cs_edit.setPlaceholderText("Path to WLC cost raster…")
        cs_row.addWidget(self.cs_edit)
        cs_browse = QPushButton("…")
        cs_browse.setFixedWidth(32)
        cs_browse.clicked.connect(self._browse_cost_surface)
        cs_row.addWidget(cs_browse)
        layout.addLayout(cs_row)

        # Start point
        start_grp = QGroupBox("Start Point")
        sg = QGridLayout(start_grp)
        sg.addWidget(QLabel("Lat:"), 0, 0)
        self.start_lat = QDoubleSpinBox()
        self.start_lat.setRange(-90, 90)
        self.start_lat.setDecimals(6)
        self.start_lat.setValue(27.7)
        sg.addWidget(self.start_lat, 0, 1)
        sg.addWidget(QLabel("Lon:"), 0, 2)
        self.start_lon = QDoubleSpinBox()
        self.start_lon.setRange(-180, 180)
        self.start_lon.setDecimals(6)
        self.start_lon.setValue(85.3)
        sg.addWidget(self.start_lon, 0, 3)
        layout.addWidget(start_grp)

        # End point
        end_grp = QGroupBox("End Point")
        eg = QGridLayout(end_grp)
        eg.addWidget(QLabel("Lat:"), 0, 0)
        self.end_lat = QDoubleSpinBox()
        self.end_lat.setRange(-90, 90)
        self.end_lat.setDecimals(6)
        self.end_lat.setValue(27.8)
        eg.addWidget(self.end_lat, 0, 1)
        eg.addWidget(QLabel("Lon:"), 0, 2)
        self.end_lon = QDoubleSpinBox()
        self.end_lon.setRange(-180, 180)
        self.end_lon.setDecimals(6)
        self.end_lon.setValue(85.4)
        eg.addWidget(self.end_lon, 0, 3)
        layout.addWidget(end_grp)

        info = QLabel("Tip: Click '📍 Set Start' / '🏁 Set End' on the map canvas\nto pick coordinates visually.")
        info.setObjectName("subtitle")
        info.setWordWrap(True)
        layout.addWidget(info)

        algo_row = QHBoxLayout()
        algo_row.addWidget(QLabel("Algorithm:"))
        self.algo_combo = QComboBox()
        self.algo_combo.addItems(["Dijkstra (8-connected)", "A* (future)"])
        algo_row.addWidget(self.algo_combo)
        layout.addLayout(algo_row)

        btn = QPushButton("Run Least Cost Path")
        btn.setObjectName("primary")
        btn.clicked.connect(self._run_lcp)
        layout.addWidget(btn)

        layout.addStretch()
        return w

    def _browse_cost_surface(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select Cost Surface", "", "GeoTIFF (*.tif *.tiff);;All (*)")
        if path:
            self.cs_edit.setText(path)

    def _run_lcp(self) -> None:
        start = (self.start_lat.value(), self.start_lon.value())
        end = (self.end_lat.value(), self.end_lon.value())
        self.run_lcp.emit(start, end)

    def get_cost_surface_path(self) -> str:
        return self.cs_edit.text().strip() if hasattr(self, "cs_edit") else ""

    def set_start_latlon(self, lat: float, lon: float) -> None:
        if hasattr(self, "start_lat"):
            self.start_lat.setValue(lat)
            self.start_lon.setValue(lon)

    def set_end_latlon(self, lat: float, lon: float) -> None:
        if hasattr(self, "end_lat"):
            self.end_lat.setValue(lat)
            self.end_lon.setValue(lon)

    # ==================================================================
    # 7. OUTPUT TAB
    # ==================================================================
    def _build_output_tab(self) -> QWidget:
        w = QWidget()
        layout = QVBoxLayout(w)
        layout.setSpacing(8)

        layout.addWidget(QLabel("Output Settings"))

        out_row = QHBoxLayout()
        out_row.addWidget(QLabel("Output Folder:"))
        self.output_dir_edit = QLineEdit()
        self.output_dir_edit.setPlaceholderText("Select output folder…")
        out_row.addWidget(self.output_dir_edit)
        browse_btn = QPushButton("…")
        browse_btn.setFixedWidth(32)
        browse_btn.clicked.connect(self._browse_output_dir)
        out_row.addWidget(browse_btn)
        layout.addLayout(out_row)

        prefix_row = QHBoxLayout()
        prefix_row.addWidget(QLabel("File prefix:"))
        self.prefix_edit = QLineEdit("lcp_output")
        prefix_row.addWidget(self.prefix_edit)
        layout.addLayout(prefix_row)

        self.auto_cleanup_cb = QCheckBox("Auto cleanup temporary workspace on exit")
        self.auto_cleanup_cb.setChecked(True)
        layout.addWidget(self.auto_cleanup_cb)

        layout.addStretch()
        return w

    def _browse_output_dir(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if d:
            self.output_dir_edit.setText(d)

    def get_output_dir(self) -> str:
        return self.output_dir_edit.text().strip() if hasattr(self, "output_dir_edit") else ""

    def get_output_prefix(self) -> str:
        return self.prefix_edit.text().strip() if hasattr(self, "prefix_edit") else "lcp_output"
