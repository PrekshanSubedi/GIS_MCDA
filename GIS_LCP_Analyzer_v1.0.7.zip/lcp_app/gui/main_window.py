"""
Main Application Window — GIS LCP Analyzer v1.0.0
===================================================
Full pipeline: Load → Reproject → Clip → DEM → Rasterize → Reclass → WLC → LCP
"""

import logging
from pathlib import Path
from typing import Optional
from functools import partial

from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QSplitter, QVBoxLayout,
    QStatusBar, QToolBar, QAction, QFileDialog,
    QMessageBox, QTabWidget, QApplication,
)
from PyQt5.QtCore import Qt, QThread, pyqtSlot, QSize

from gui.layer_panel import LayerPanel
from gui.map_canvas import MapCanvas
from gui.analysis_panel import AnalysisPanel
from gui.ahp_widget import AHPWidget
from gui.log_console import LogConsole
from core.layer_model import LayerInfo, LayerType, LayerRole
from core.project_manager import ProjectManager
from utils.config import AppConfig
from utils.helpers import get_temp_dir, cleanup_temp_dir

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):

    def __init__(self, config: AppConfig) -> None:
        super().__init__()
        self.config          = config
        self.project_manager = ProjectManager()
        self._layers: dict[str, LayerInfo] = {}
        self._workspace      = get_temp_dir()

        # Keep strong references to workers — prevents "QThread destroyed while running"
        self._workers: list = []
        self._busy = False

        self._ahp_weights: dict[str, float] = {}

        # Pipeline state
        self._dem_path: Optional[str]          = None
        self._dem_derivatives: dict[str, str]  = {}
        self._distance_rasters: dict[str, str] = {}
        self._type_rasters: dict[str, str]     = {}
        self._reclass_rasters: dict[str, str]  = {}
        self._constraint_mask: Optional[str]   = None
        self._cost_surface: Optional[str]      = None

        self._build_ui()
        self._create_menu()
        self._create_toolbar()
        self._connect_signals()

        self.setWindowTitle("GIS Least Cost Path Analyzer  |  GIS-TL-DS-2026-001")
        self.resize(config.get("window_width", 1600), config.get("window_height", 900))
        self.log("Application started. Load datasets to begin.", "SUCCESS")

    # ==================================================================
    # UI
    # ==================================================================
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(4)

        h_split = QSplitter(Qt.Horizontal)

        self.layer_panel = LayerPanel()
        self.layer_panel.setMinimumWidth(220)
        self.layer_panel.setMaximumWidth(320)
        h_split.addWidget(self.layer_panel)

        centre_tabs = QTabWidget()
        self.map_canvas = MapCanvas()
        centre_tabs.addTab(self.map_canvas, "Map Canvas")
        self.ahp_widget = AHPWidget()
        centre_tabs.addTab(self.ahp_widget, "AHP Matrix")
        h_split.addWidget(centre_tabs)

        self.analysis_panel = AnalysisPanel()
        self.analysis_panel.setMinimumWidth(320)
        self.analysis_panel.setMaximumWidth(430)
        h_split.addWidget(self.analysis_panel)

        h_split.setStretchFactor(0, 0)
        h_split.setStretchFactor(1, 1)
        h_split.setStretchFactor(2, 0)
        h_split.setSizes([260, 940, 370])
        root.addWidget(h_split, stretch=1)

        self.log_console = LogConsole()
        root.addWidget(self.log_console, stretch=0)
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Ready")

    def _create_menu(self) -> None:
        mb = self.menuBar()
        fm = mb.addMenu("&File")
        for label, shortcut, slot in [
            ("New Project",   "Ctrl+N", self._new_project),
            ("Open Project",  "Ctrl+O", self._open_project),
            ("Save Project",  "Ctrl+S", self._save_project),
        ]:
            a = QAction(label, self); a.setShortcut(shortcut)
            a.triggered.connect(slot); fm.addAction(a)
        fm.addSeparator()
        ex = QAction("Exit", self); ex.triggered.connect(self.close); fm.addAction(ex)

        vm = mb.addMenu("&View")
        for label, theme in [("Dark Theme", "dark"), ("Light Theme", "light")]:
            a = QAction(label, self)
            a.triggered.connect(lambda _, t=theme: self._set_theme(t))
            vm.addAction(a)

        hm = mb.addMenu("&Help")
        ab = QAction("About", self); ab.triggered.connect(self._show_about)
        hm.addAction(ab)

    def _create_toolbar(self) -> None:
        tb = QToolBar("Main"); tb.setMovable(False); tb.setIconSize(QSize(18, 18))
        self.addToolBar(tb)

        def add(label, slot):
            if label == "|":
                tb.addSeparator(); return
            a = QAction(label, self); a.triggered.connect(slot); tb.addAction(a)

        add("Add Layer",          lambda: self.analysis_panel._browse_layer("Auxiliary"))
        add("|", None)
        add("RUN FULL PIPELINE",  self._run_full_pipeline)
        add("|", None)
        add("1. Reproject",       lambda: self._run_reproject(self.analysis_panel.get_target_crs()))
        add("2. Clip Corridor",   self._run_corridor_clip)
        add("3. DEM Derivs",      lambda: self._run_dem_derivatives(
                                      self.analysis_panel.dem_path_edit.text().strip()))
        add("4. Rasterize All",   self._run_full_rasterization)
        add("5. Reclassify",      lambda: self._run_reclassify(
                                      self.analysis_panel.get_reclass_configs()))
        add("6. WLC Overlay",     self._run_weighted_overlay)
        add("7. Run LCP",         self._trigger_lcp)
        add("|", None)
        add("Save Project",       self._save_project)

    def _connect_signals(self) -> None:
        ap = self.analysis_panel
        ap.load_layer.connect(self._load_layer)
        ap.run_reproject.connect(self._run_reproject)
        ap.run_dem_derivatives.connect(self._run_dem_derivatives)
        ap.run_reclassify.connect(self._run_reclassify)
        ap.run_weighted_overlay.connect(self._run_weighted_overlay)
        # run_lcp signal is intentionally NOT connected here —
        # the LCP tab button calls _trigger_lcp directly via _run_lcp in analysis_panel
        # We intercept it by overriding the button's connection below:
        ap.run_lcp.connect(self._on_lcp_signal)
        self.ahp_widget.weights_updated.connect(self._on_ahp_weights_updated)
        self.ahp_widget.consistency_failed.connect(
            lambda m: self.log(f"AHP Warning: {m[:120]}", "WARNING"))
        self.ahp_widget.consistency_passed.connect(
            lambda: self.log("AHP consistency OK (CR <= 0.10)", "SUCCESS"))
        self.layer_panel.layer_removed.connect(self._on_layer_removed)
        self.layer_panel.layer_selected.connect(self._on_layer_selected)
        self.map_canvas.point_clicked.connect(self._on_map_point_clicked)

    # ==================================================================
    # Layer Loading
    # ==================================================================
    @pyqtSlot(str, str)
    def _load_layer(self, path: str, role_hint: str) -> None:
        if not Path(path).exists():
            self.log(f"File not found: {path}", "ERROR"); return
        try:
            layer = self._detect_layer(path, role_hint)
            self._layers[layer.layer_id] = layer
            self.layer_panel.add_layer(layer)
            self.log(f"Loaded: {layer.display_name}  [{layer.short_crs()}]", "SUCCESS")
            if layer.role == LayerRole.DEM:
                self.analysis_panel.dem_path_edit.setText(path)
                self._dem_path = path
            if layer.is_raster:
                self.map_canvas.display_raster(path, layer.display_name)
        except Exception as e:
            self.log(f"Error loading {path}: {e}", "ERROR")
            logger.error("Layer load error", exc_info=True)

    def _detect_layer(self, path: str, role_hint: str) -> LayerInfo:
        layer = LayerInfo()
        layer.file_path = path
        layer.name = Path(path).stem
        for r in LayerRole:
            if r.value == role_hint or r.name == role_hint.replace(" ", "_").upper():
                layer.role = r; break
        role_colors = {
            LayerRole.BUILDINGS:      (248, 113, 113),
            LayerRole.SETTLEMENTS:    (251, 191, 36),
            LayerRole.DEM:            (134, 239, 172),
            LayerRole.LULC:           (167, 139, 250),
            LayerRole.WATERWAYS:      (96, 165, 250),
            LayerRole.ROADS:          (251, 146, 60),
            LayerRole.STUDY_CORRIDOR: (232, 121, 249),
            LayerRole.START_POINT:    (74, 222, 128),
            LayerRole.END_POINT:      (248, 113, 113),
        }
        layer.color = role_colors.get(layer.role, (148, 163, 184))
        ext = Path(path).suffix.lower()
        if ext in (".tif", ".tiff", ".img", ".asc", ".dem"):
            layer.layer_type = LayerType.RASTER
            try:
                import rasterio
                with rasterio.open(path) as src:
                    layer.crs = src.crs.to_string() if src.crs else "Unknown"
                    layer.resolution = (abs(src.transform.a), abs(src.transform.e))
                    layer.band_count = src.count
                    layer.nodata_value = src.nodata
                    b = src.bounds
                    layer.extent = (b.left, b.bottom, b.right, b.top)
            except Exception: pass
        else:
            try:
                import geopandas as gpd
                gdf = gpd.read_file(path, rows=5)
                layer.crs = gdf.crs.to_string() if gdf.crs else "Unknown"
                if len(gdf):
                    gt = gdf.geometry.iloc[0].geom_type.lower()
                    if "polygon" in gt:   layer.layer_type = LayerType.VECTOR_POLYGON
                    elif "point" in gt:   layer.layer_type = LayerType.VECTOR_POINT
                    elif "line" in gt:    layer.layer_type = LayerType.VECTOR_LINE
                full = gpd.read_file(path)
                layer.feature_count = len(full)
                b = full.total_bounds
                layer.extent = (b[0], b[1], b[2], b[3])
            except Exception: pass
        return layer

    # ==================================================================
    # Helpers
    # ==================================================================
    def _get_dem_path(self) -> Optional[str]:
        for lyr in self._layers.values():
            if lyr.role == LayerRole.DEM:
                return lyr.reprojected_path or lyr.file_path
        return None

    def _get_corridor_path(self) -> Optional[str]:
        for lyr in self._layers.values():
            if lyr.role == LayerRole.STUDY_CORRIDOR:
                return lyr.reprojected_path or lyr.file_path
        return None

    # ==================================================================
    # FULL CHAINED PIPELINE
    # ==================================================================
    def _run_full_pipeline(self) -> None:
        if not self._layers:
            QMessageBox.warning(self, "No Layers", "Load all datasets first."); return
        self.log("=== Starting Full Analysis Pipeline ===", "SUCCESS")
        self._step_reproject()

    def _step_reproject(self) -> None:
        from processing.workers import ReprojectWorker
        worker = ReprojectWorker(
            list(self._layers.values()),
            self.analysis_panel.get_target_crs(),
            str(self._workspace / "reproj"))
        def done(r):
            for lyr in self._layers.values():
                if lyr.role == LayerRole.DEM and lyr.reprojected_path:
                    self._dem_path = lyr.reprojected_path
                    self.analysis_panel.dem_path_edit.setText(self._dem_path)
            self._step_clip()
        self._run_worker(worker, "[1/6] Reprojecting...", done)

    def _step_clip(self) -> None:
        corridor = self._get_corridor_path()
        if not corridor:
            self.log("No study corridor — skipping clip.", "WARNING")
            self._step_dem(); return
        raster_paths = {lid: (lyr.reprojected_path or lyr.file_path)
                        for lid, lyr in self._layers.items() if lyr.is_raster}
        if not raster_paths:
            self._step_dem(); return
        from processing.workers import CorridorClipWorker
        worker = CorridorClipWorker(raster_paths, corridor, str(self._workspace / "clipped"))
        def done(r):
            for lid, p in r.items():
                if lid in self._layers:
                    self._layers[lid].reprojected_path = p
                    if self._layers[lid].role == LayerRole.DEM:
                        self._dem_path = p
                        self.analysis_panel.dem_path_edit.setText(p)
            self._step_dem()
        self._run_worker(worker, "[2/6] Clipping to corridor...", done)

    def _step_dem(self) -> None:
        dem = self._get_dem_path()
        if not dem:
            QMessageBox.warning(self, "No DEM", "No DEM found."); return
        from processing.workers import DEMDerivativesWorker
        worker = DEMDerivativesWorker(dem, str(self._workspace / "dem_deriv"))
        def done(r):
            self._dem_derivatives.update(r)
            if "slope" in r:
                self.map_canvas.display_raster(r["slope"], "Slope")
            self._step_rasterize()
        self._run_worker(worker, "[3/6] DEM derivatives...", done)

    def _step_rasterize(self) -> None:
        dem = self._get_dem_path()
        if not dem: return
        from processing.workers import FullRasterizationWorker
        worker = FullRasterizationWorker(
            list(self._layers.values()), dem,
            str(self._workspace / "rasterized"),
            self.analysis_panel.get_building_buffer())
        def done(r):
            self._distance_rasters.update(r.get("distance_rasters", {}))
            self._type_rasters.update(r.get("type_rasters", {}))
            if r.get("constraint_mask"):
                self._constraint_mask = r["constraint_mask"]
            self._step_reclassify()
        self._run_worker(worker, "[4/6] Rasterizing vectors...", done)

    def _step_reclassify(self) -> None:
        configs = self.analysis_panel.get_reclass_configs()
        self._run_reclassify(configs, next_cb=self._step_wlc)

    def _step_wlc(self) -> None:
        self._run_weighted_overlay()

    # ==================================================================
    # Individual pipeline steps (also callable standalone)
    # ==================================================================
    def _run_reproject(self, target_crs: str) -> None:
        if not self._layers:
            QMessageBox.warning(self, "No Layers", "Load layers first."); return
        from processing.workers import ReprojectWorker
        worker = ReprojectWorker(
            list(self._layers.values()), target_crs,
            str(self._workspace / "reproj"))
        def done(r):
            for lyr in self._layers.values():
                if lyr.role == LayerRole.DEM and lyr.reprojected_path:
                    self._dem_path = lyr.reprojected_path
                    self.analysis_panel.dem_path_edit.setText(self._dem_path)
        self._run_worker(worker, "Reprojecting all layers...", done)

    def _run_corridor_clip(self) -> None:
        corridor = self._get_corridor_path()
        if not corridor:
            QMessageBox.warning(self, "No Corridor", "Load a Study Corridor layer first."); return
        raster_paths = {lid: (lyr.reprojected_path or lyr.file_path)
                        for lid, lyr in self._layers.items() if lyr.is_raster}
        if not raster_paths:
            QMessageBox.warning(self, "No Rasters", "No raster layers to clip."); return
        from processing.workers import CorridorClipWorker
        worker = CorridorClipWorker(raster_paths, corridor, str(self._workspace / "clipped"))
        def done(r):
            for lid, p in r.items():
                if lid in self._layers:
                    self._layers[lid].reprojected_path = p
                    if self._layers[lid].role == LayerRole.DEM:
                        self._dem_path = p
                        self.analysis_panel.dem_path_edit.setText(p)
        self._run_worker(worker, "Clipping to study corridor...", done)

    def _run_dem_derivatives(self, dem_path: str) -> None:
        if not dem_path or not Path(dem_path).exists():
            QMessageBox.warning(self, "DEM Missing", "Select a valid DEM."); return
        from processing.workers import DEMDerivativesWorker
        worker = DEMDerivativesWorker(dem_path, str(self._workspace / "dem_deriv"))
        def done(r):
            self._dem_derivatives.update(r)
            if "slope" in r:
                self.map_canvas.display_raster(r["slope"], "Slope (degrees)")
        self._run_worker(worker, "Generating DEM derivatives...", done)

    def _run_full_rasterization(self) -> None:
        dem = self._get_dem_path()
        if not dem:
            QMessageBox.warning(self, "DEM Required", "Reproject/clip DEM first."); return
        from processing.workers import FullRasterizationWorker
        worker = FullRasterizationWorker(
            list(self._layers.values()), dem,
            str(self._workspace / "rasterized"),
            self.analysis_panel.get_building_buffer())
        def done(r):
            self._distance_rasters.update(r.get("distance_rasters", {}))
            self._type_rasters.update(r.get("type_rasters", {}))
            if r.get("constraint_mask"):
                self._constraint_mask = r["constraint_mask"]
            self.log(f"Distance rasters: {list(self._distance_rasters.keys())}", "SUCCESS")
        self._run_worker(worker, "Rasterizing vectors + distance rasters...", done)

    def _run_reclassify(self, configs, next_cb=None) -> None:
        name_to_src: dict[str, str] = {}
        if self._dem_derivatives.get("slope"):
            name_to_src["Slope"] = self._dem_derivatives["slope"]
        if self._dem_derivatives.get("tri"):
            name_to_src["TRI"] = self._dem_derivatives["tri"]
        if self._type_rasters.get("settlement"):
            name_to_src["Settlement Type"] = self._type_rasters["settlement"]
        if self._distance_rasters.get("settlement"):
            name_to_src["Settlement Distance"] = self._distance_rasters["settlement"]
        if self._distance_rasters.get("waterway"):
            name_to_src["Waterway Distance"] = self._distance_rasters["waterway"]
        if self._distance_rasters.get("road"):
            name_to_src["Road Distance"] = self._distance_rasters["road"]
        for lyr in self._layers.values():
            if lyr.role == LayerRole.LULC:
                name_to_src["LULC"] = lyr.reprojected_path or lyr.file_path
        if self._constraint_mask:
            name_to_src["Building Distance"] = self._constraint_mask

        tasks = []
        for cfg in configs:
            src = name_to_src.get(cfg["name"])
            if src and Path(src).exists():
                tasks.append({"src": src, "table": cfg["table"],
                               "id": cfg["name"].lower().replace(" ", "_")})
                self.log(f"  Reclass queued: {cfg['name']}")
            else:
                self.log(f"  Skipping (no source): {cfg['name']}", "WARNING")

        if not tasks:
            QMessageBox.warning(self, "Nothing to Reclassify",
                "Run 'Rasterize All' before Reclassify, or use 'RUN FULL PIPELINE'."); return

        from processing.workers import ReclassifyWorker
        worker = ReclassifyWorker(tasks, str(self._workspace / "reclass"))
        def done(r):
            self._reclass_rasters.update(r)
            self.log(f"Reclassified {len(r)} layers.", "SUCCESS")
            if callable(next_cb):
                next_cb()
        self._run_worker(worker, f"Reclassifying {len(tasks)} layers...", done)

    def _run_weighted_overlay(self) -> None:
        if not self._ahp_weights:
            QMessageBox.warning(self, "AHP Required",
                "Open the AHP Matrix tab and verify weights first."); return
        if not self.ahp_widget.is_consistent():
            QMessageBox.critical(self, "Inconsistent AHP",
                "CR > 0.10. Fix the comparison matrix."); return
        if not self._reclass_rasters:
            QMessageBox.warning(self, "Reclassify First",
                "Run reclassification before WLC."); return

        CRITERIA_MAP = {
            "Buildings":  "building_distance",
            "Settlement": "settlement_type",
            "Slope":      "slope",
            "TRI":        "tri",
            "Land Use":   "lulc",
            "Waterways":  "waterway_distance",
            "Roads":      "road_distance",
        }
        layer_paths, weights = [], []
        for crit, w in self._ahp_weights.items():
            key  = CRITERIA_MAP.get(crit, crit.lower().replace(" ", "_"))
            path = self._reclass_rasters.get(key)
            if path and Path(path).exists():
                layer_paths.append(path); weights.append(w)
                self.log(f"  WLC: {crit} weight={w:.3f}")
            else:
                self.log(f"  WLC skip (no raster): {crit} [{key}]", "WARNING")

        if not layer_paths:
            QMessageBox.warning(self, "No Layers", "No reclassified rasters match criteria."); return

        total = sum(weights)
        weights = [w / total for w in weights]
        out = str(self._workspace / "cost_surface.tif")
        constraint = self._constraint_mask if self.analysis_panel.use_constraint_mask() else None

        from processing.workers import WeightedOverlayWorker
        worker = WeightedOverlayWorker(layer_paths, weights, out, constraint)
        def done(r):
            cs = r.get("cost_surface")
            if cs:
                self._cost_surface = cs
                self.analysis_panel.cs_edit.setText(cs)
                self.map_canvas.display_raster(cs, "WLC Cost Surface")
                self.log("Cost surface ready. Set Start/End then Run LCP.", "SUCCESS")
        self._run_worker(worker, "Computing WLC cost surface...", done)

    # ==================================================================
    # LCP
    # ==================================================================
    @pyqtSlot(object, object)
    def _on_lcp_signal(self, start, end) -> None:
        """Receives the run_lcp signal from the analysis panel."""
        self._do_run_lcp(start, end)

    def _trigger_lcp(self) -> None:
        """Called from toolbar — reads coords directly without going through signal."""
        start = (self.analysis_panel.start_lat.value(),
                 self.analysis_panel.start_lon.value())
        end   = (self.analysis_panel.end_lat.value(),
                 self.analysis_panel.end_lon.value())
        self._do_run_lcp(start, end)

    def _do_run_lcp(self, start: tuple, end: tuple) -> None:
        """Actual LCP execution — always called with plain Python tuples."""
        cs_path = self.analysis_panel.get_cost_surface_path()
        if not cs_path or not Path(cs_path).exists():
            QMessageBox.warning(self, "Cost Surface Missing",
                "Generate the WLC cost surface first."); return

        # Auto-detect start/end from shapefiles if available
        start = self._resolve_point(LayerRole.START_POINT) or start
        end   = self._resolve_point(LayerRole.END_POINT)   or end

        output_dir = self.analysis_panel.get_output_dir() or str(self._workspace / "lcp_outputs")
        prefix     = self.analysis_panel.get_output_prefix()

        from processing.workers import LCPWorker
        worker = LCPWorker(cs_path, start, end, output_dir, prefix)
        def done(r):
            shp = r.get("shapefile")
            if shp:
                self.map_canvas.add_vector_overlay(shp, color="yellow",
                                                   linewidth=2.5, label="LCP Route")
                self.log(f"Optimal route: {shp}", "SUCCESS")
            if r.get("kml"):
                self.log(f"KML: {r['kml']}", "SUCCESS")
            if r.get("cost_distance"):
                self.map_canvas.display_raster(r["cost_distance"], "Cost Distance")
            self.log("All LCP outputs generated.", "SUCCESS")
        self._run_worker(worker, "Running Least Cost Path (Dijkstra)...", done)

    def _resolve_point(self, role: LayerRole) -> Optional[tuple]:
        for lyr in self._layers.values():
            if lyr.role == role:
                src = lyr.reprojected_path or lyr.file_path
                try:
                    import geopandas as gpd
                    from pyproj import Transformer
                    gdf = gpd.read_file(src)
                    if not len(gdf): continue
                    geom = gdf.geometry.iloc[0]
                    pt = geom if geom.geom_type == "Point" else geom.centroid
                    crs = gdf.crs.to_string() if gdf.crs else "EPSG:32645"
                    lon, lat = Transformer.from_crs(
                        crs, "EPSG:4326", always_xy=True).transform(pt.x, pt.y)
                    self.log(f"Auto-detected {role.value}: lat={lat:.5f}, lon={lon:.5f}", "SUCCESS")
                    if role == LayerRole.START_POINT:
                        self.analysis_panel.set_start_latlon(lat, lon)
                    else:
                        self.analysis_panel.set_end_latlon(lat, lon)
                    return (lat, lon)
                except Exception as e:
                    self.log(f"Could not read {role.value}: {e}", "WARNING")
        return None

    # ==================================================================
    # Core worker runner — single clean implementation, no duplicates
    # ==================================================================
    def _run_worker(self, worker, msg: str, done_cb=None) -> None:
        """
        Start a background worker safely:
        - Blocks if already busy
        - Keeps a strong Python reference (prevents GC crash)
        - Connects signals ONCE per worker instance
        - Calls done_cb(results) on success
        """
        if self._busy:
            QMessageBox.warning(self, "Busy", "A processing task is already running."); return

        self._busy = True
        self._workers.append(worker)   # strong reference

        self.log(msg)
        self.log_console.set_status(msg)
        self.statusBar().showMessage(msg)

        worker.signals.log.connect(lambda m: self.log(m))
        worker.signals.progress.connect(self.log_console.set_progress)
        worker.signals.error.connect(self._on_worker_error)

        # Use a one-shot lambda that captures done_cb by value
        _cb = done_cb  # local binding
        def _on_finished(results: dict) -> None:
            self._busy = False
            self.log_console.set_status("Ready")
            self.log_console.set_progress(100)
            self.statusBar().showMessage("Ready")
            # Remove from ref list after Qt is done
            if worker in self._workers:
                self._workers.remove(worker)
            if callable(_cb):
                _cb(results)

        worker.signals.finished.connect(_on_finished)
        worker.start()

    def _on_worker_error(self, error_msg: str) -> None:
        self._busy = False
        self.log(f"ERROR: {error_msg[:400]}", "ERROR")
        self.log_console.set_status("Error")
        QMessageBox.critical(self, "Processing Error", error_msg[:700])

    # ==================================================================
    # Slots
    # ==================================================================
    @pyqtSlot(dict)
    def _on_ahp_weights_updated(self, weights: dict) -> None:
        self._ahp_weights = weights
        self.analysis_panel.update_weights_display(weights)

    @pyqtSlot(str)
    def _on_layer_removed(self, layer_id: str) -> None:
        self._layers.pop(layer_id, None)

    @pyqtSlot(str)
    def _on_layer_selected(self, layer_id: str) -> None:
        lyr = self._layers.get(layer_id)
        if lyr and lyr.is_raster:
            self.map_canvas.display_raster(
                lyr.reprojected_path or lyr.file_path, lyr.display_name)

    @pyqtSlot(float, float)
    def _on_map_point_clicked(self, x: float, y: float) -> None:
        try:
            from pyproj import Transformer
            src_crs = next(
                (lyr.crs for lyr in self._layers.values()
                 if lyr.crs and lyr.crs != "Unknown"), "EPSG:32645")
            lon, lat = Transformer.from_crs(
                src_crs, "EPSG:4326", always_xy=True).transform(x, y)
            self.log(f"Map click: lat={lat:.5f}, lon={lon:.5f}")
            if self.map_canvas.set_start_btn.isChecked():
                self.analysis_panel.set_start_latlon(lat, lon)
            elif self.map_canvas.set_end_btn.isChecked():
                self.analysis_panel.set_end_latlon(lat, lon)
        except Exception as e:
            logger.debug("Point conversion: %s", e)

    # ==================================================================
    # Project save / load
    # ==================================================================
    def _new_project(self) -> None:
        if QMessageBox.question(self, "New Project", "Clear everything and start fresh?",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self.layer_panel.clear_all()
            self._layers.clear()
            self._dem_derivatives.clear()
            self._distance_rasters.clear()
            self._type_rasters.clear()
            self._reclass_rasters.clear()
            self._cost_surface = self._constraint_mask = self._dem_path = None
            self.map_canvas._raster_path = None
            self.map_canvas.refresh()
            self.log("New project started.", "SUCCESS")

    def _save_project(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Project", "project.lcpproj", "LCP Project (*.lcpproj)")
        if not path: return
        try:
            self.project_manager.save(
                Path(path), list(self._layers.values()),
                self.ahp_widget.engine.pcm.tolist(),
                list(self.ahp_widget.engine.criteria),
                self.config.all())
            self.log(f"Project saved: {path}", "SUCCESS")
            self.config.add_recent_project(path)
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))

    def _open_project(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Project", "", "LCP Project (*.lcpproj)")
        if not path: return
        try:
            project = self.project_manager.load(Path(path))
            self.layer_panel.clear_all(); self._layers.clear()
            import numpy as np
            for ld in project.get("layers", []):
                lyr = ProjectManager.deserialize_layer(ld)
                self._layers[lyr.layer_id] = lyr
                self.layer_panel.add_layer(lyr)
            m = project.get("ahp_matrix")
            c = project.get("ahp_criteria")
            if m and c:
                from ahp.ahp_engine import AHPEngine
                self.ahp_widget.set_engine(AHPEngine(c, np.array(m)))
            self.log(f"Project loaded: {path}", "SUCCESS")
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))

    # ==================================================================
    # Misc
    # ==================================================================
    def log(self, msg: str, level: str = "INFO") -> None:
        self.log_console.log(msg, level)

    def _set_theme(self, theme: str) -> None:
        from main import _DARK_STYLESHEET, _LIGHT_STYLESHEET
        QApplication.instance().setStyleSheet(
            _DARK_STYLESHEET if theme == "dark" else _LIGHT_STYLESHEET)
        self.config.set("theme", theme)

    def _show_about(self) -> None:
        QMessageBox.about(self, "About",
            "<b>GIS Least Cost Path Analyzer</b><br>v1.0.0 | GIS-TL-DS-2026-001<br><br>"
            "AHP weighted overlay + Dijkstra LCP<br>"
            "Stack: PyQt5, GDAL, Rasterio, GeoPandas, NumPy, Scipy")

    def closeEvent(self, event) -> None:
        if self.config.get("auto_cleanup", True):
            cleanup_temp_dir()
        self.config.set("window_width", self.width())
        self.config.set("window_height", self.height())
        event.accept()
