"""
Map Canvas Widget
==================
Matplotlib-based map canvas embedded in Qt for displaying:
  - Raster layers (DEM, slope, cost surface, etc.)
  - Vector overlays (paths, study area, etc.)
  - Start/end points
  - Legend, colorbar, north arrow
  - Zoom / pan (via matplotlib toolbar)
"""

import logging
from pathlib import Path
from typing import Optional

import numpy as np
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QComboBox, QLabel,
    QPushButton, QSlider,
)
from PyQt5.QtCore import Qt, pyqtSignal

try:
    import matplotlib
    matplotlib.use("Qt5Agg")
    from matplotlib.backends.backend_qt5agg import (
        FigureCanvasQTAgg as FigureCanvas,
        NavigationToolbar2QT as NavigationToolbar,
    )
    from matplotlib.figure import Figure
    import matplotlib.patches as mpatches
    import matplotlib.colors as mcolors
    MPL_OK = True
except ImportError:
    MPL_OK = False
    FigureCanvas = None
    NavigationToolbar = None
    Figure = None

try:
    import rasterio
    from rasterio.plot import show as rio_show
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False

try:
    import geopandas as gpd
    GPANDAS_OK = True
except ImportError:
    GPANDAS_OK = False

logger = logging.getLogger(__name__)

COLORMAPS = ["terrain", "viridis", "plasma", "RdYlGn_r", "gray", "hot_r", "coolwarm"]


class MapCanvas(QWidget):
    """
    Map display widget using Matplotlib/Qt5Agg backend.

    Supports basic raster display, vector overlay, and interactive
    zoom/pan via Matplotlib's native navigation toolbar.
    """

    point_clicked = pyqtSignal(float, float)   # x, y in map CRS

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._raster_path: Optional[str] = None
        self._vector_paths: list[dict] = []
        self._start_xy: Optional[tuple] = None
        self._end_xy: Optional[tuple] = None
        self._path_coords: list = []
        self._colormap = "terrain"
        self._click_mode = None  # "start" | "end" | None
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        if not MPL_OK:
            layout.addWidget(QLabel("Matplotlib not available — install matplotlib."))
            return

        # Controls row
        ctrl_row = QHBoxLayout()

        self.cmap_combo = QComboBox()
        self.cmap_combo.addItems(COLORMAPS)
        self.cmap_combo.setFixedWidth(110)
        self.cmap_combo.setToolTip("Colormap")
        self.cmap_combo.currentTextChanged.connect(self._on_cmap_changed)
        ctrl_row.addWidget(QLabel("Colormap:"))
        ctrl_row.addWidget(self.cmap_combo)

        self.opacity_slider = QSlider(Qt.Horizontal)
        self.opacity_slider.setRange(10, 100)
        self.opacity_slider.setValue(100)
        self.opacity_slider.setFixedWidth(100)
        self.opacity_slider.setToolTip("Raster opacity")
        self.opacity_slider.valueChanged.connect(lambda _: self.refresh())
        ctrl_row.addWidget(QLabel("Opacity:"))
        ctrl_row.addWidget(self.opacity_slider)

        ctrl_row.addStretch()

        self.set_start_btn = QPushButton("📍 Set Start")
        self.set_start_btn.setCheckable(True)
        self.set_start_btn.setToolTip("Click on map to set start point")
        self.set_start_btn.clicked.connect(lambda c: self._set_click_mode("start" if c else None))
        ctrl_row.addWidget(self.set_start_btn)

        self.set_end_btn = QPushButton("🏁 Set End")
        self.set_end_btn.setCheckable(True)
        self.set_end_btn.setToolTip("Click on map to set end point")
        self.set_end_btn.clicked.connect(lambda c: self._set_click_mode("end" if c else None))
        ctrl_row.addWidget(self.set_end_btn)

        layout.addLayout(ctrl_row)

        # Figure
        self.figure = Figure(facecolor="#1e1e2e", tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.canvas.mpl_connect("button_press_event", self._on_map_click)

        self.ax = self.figure.add_subplot(111)
        self._style_axes()

        self.toolbar = NavigationToolbar(self.canvas, self)
        self.toolbar.setStyleSheet("background: #181825; color: #cdd6f4;")

        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)

        self._draw_placeholder()

    def _style_axes(self) -> None:
        self.ax.set_facecolor("#0d0d1a")
        self.ax.tick_params(colors="#6c7086")
        for spine in self.ax.spines.values():
            spine.set_edgecolor("#45475a")

    # ------------------------------------------------------------------
    # Display methods
    # ------------------------------------------------------------------

    def display_raster(self, path: str, title: str = "") -> None:
        """Display a raster file on the canvas."""
        if not (MPL_OK and RASTERIO_OK):
            return
        self._raster_path = path
        self.refresh(title=title)

    def add_vector_overlay(self, path: str, color: str = "red", linewidth: float = 1.5, label: str = "") -> None:
        """Add a vector layer overlay."""
        self._vector_paths.append({"path": path, "color": color, "lw": linewidth, "label": label})
        self.refresh()

    def clear_vectors(self) -> None:
        self._vector_paths.clear()
        self.refresh()

    def set_path_coords(self, coords: list) -> None:
        """Display an LCP path as a line overlay."""
        self._path_coords = coords
        self.refresh()

    def set_start_xy(self, x: float, y: float) -> None:
        self._start_xy = (x, y)
        self.refresh()

    def set_end_xy(self, x: float, y: float) -> None:
        self._end_xy = (x, y)
        self.refresh()

    def refresh(self, title: str = "") -> None:
        """Re-render all layers."""
        if not MPL_OK:
            return
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)
        self._style_axes()

        if self._raster_path:
            self._render_raster(title)
        else:
            self._draw_placeholder()
            return

        if self._vector_paths:
            self._render_vectors()

        if self._path_coords:
            xs = [c[0] for c in self._path_coords]
            ys = [c[1] for c in self._path_coords]
            self.ax.plot(xs, ys, color="#f9e2af", linewidth=2.5, label="LCP Route", zorder=10)

        if self._start_xy:
            self.ax.plot(*self._start_xy, "g^", ms=12, zorder=11, label="Start")
        if self._end_xy:
            self.ax.plot(*self._end_xy, "rs", ms=12, zorder=11, label="End")

        if self.ax.get_legend_handles_labels()[1]:
            self.ax.legend(loc="upper right", fontsize=8,
                           facecolor="#313244", edgecolor="#45475a", labelcolor="#cdd6f4")

        self.canvas.draw_idle()

    def _render_raster(self, title: str = "") -> None:
        """Render raster with automatic downsampling to avoid OOM on large files."""
        MAX_DISPLAY_PX = 2048  # cap to avoid allocating 70+ GiB arrays
        try:
            with rasterio.open(self._raster_path) as src:
                h, w = src.height, src.width
                factor = max(1, max(h, w) // MAX_DISPLAY_PX)
                out_h = max(1, h // factor)
                out_w = max(1, w // factor)
                data = src.read(
                    1,
                    out_shape=(out_h, out_w),
                    resampling=rasterio.enums.Resampling.average,
                ).astype(np.float32)
                extent = [src.bounds.left, src.bounds.right,
                          src.bounds.bottom, src.bounds.top]
                nodata = src.nodata
                if factor > 1:
                    logger.info("Display downsampled %dx%d -> %dx%d (1:%d)", w, h, out_w, out_h, factor)
        except Exception as e:
            logger.error("Raster render error: %s", e)
            self._draw_placeholder(str(e))
            return

        if nodata is not None:
            data[data == nodata] = np.nan

        alpha = self.opacity_slider.value() / 100.0
        cmap = self.cmap_combo.currentText()
        vmin = np.nanpercentile(data, 2)
        vmax = np.nanpercentile(data, 98)

        im = self.ax.imshow(
            data, extent=extent, origin="upper",
            cmap=cmap, vmin=vmin, vmax=vmax, alpha=alpha,
            interpolation="bilinear",
        )
        self.figure.colorbar(im, ax=self.ax, shrink=0.6, pad=0.02)
        t = title or Path(self._raster_path).stem
        self.ax.set_title(t, color="#89b4fa", fontsize=10)

    def _render_vectors(self) -> None:
        if not GPANDAS_OK:
            return
        for vdict in self._vector_paths:
            try:
                gdf = gpd.read_file(vdict["path"])
                gdf.plot(ax=self.ax, color=vdict["color"],
                         linewidth=vdict["lw"], alpha=0.8, label=vdict["label"])
            except Exception as e:
                logger.warning("Vector overlay error: %s", e)

    def _draw_placeholder(self, msg: str = "") -> None:
        self.ax.set_facecolor("#0d0d1a")
        txt = msg or "Load a raster layer to display the map"
        self.ax.text(
            0.5, 0.5, txt,
            transform=self.ax.transAxes,
            ha="center", va="center",
            color="#45475a", fontsize=12,
        )
        self.ax.set_xticks([])
        self.ax.set_yticks([])
        self.canvas.draw_idle()

    # ------------------------------------------------------------------
    # Click interaction
    # ------------------------------------------------------------------
    def _set_click_mode(self, mode: Optional[str]) -> None:
        self._click_mode = mode
        if mode == "start":
            self.set_end_btn.setChecked(False)
        elif mode == "end":
            self.set_start_btn.setChecked(False)

    def _on_map_click(self, event) -> None:
        if event.inaxes != self.ax or event.xdata is None:
            return
        x, y = event.xdata, event.ydata
        if self._click_mode == "start":
            self._start_xy = (x, y)
            self.set_start_btn.setChecked(False)
            self._click_mode = None
        elif self._click_mode == "end":
            self._end_xy = (x, y)
            self.set_end_btn.setChecked(False)
            self._click_mode = None
        else:
            return
        self.point_clicked.emit(x, y)
        self.refresh()

    def _on_cmap_changed(self, cmap: str) -> None:
        self._colormap = cmap
        self.refresh()
