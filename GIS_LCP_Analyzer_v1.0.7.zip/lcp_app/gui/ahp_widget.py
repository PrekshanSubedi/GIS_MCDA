"""
AHP Matrix Editor Widget
=========================
Interactive table for editing pairwise comparison matrix with
live recalculation of weights, CI, and CR.
"""

import logging
from typing import Optional

import numpy as np
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QDoubleSpinBox, QGroupBox,
    QAbstractItemView, QHeaderView, QFrame, QSizePolicy, QMessageBox,
)
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor, QBrush, QFont

from ahp.ahp_engine import AHPEngine, AHPResult

logger = logging.getLogger(__name__)


class AHPWidget(QWidget):
    """
    AHP pairwise comparison matrix editor.

    Signals
    -------
    weights_updated : dict[str, float]  — criteria → weight mapping
    consistency_failed : str            — warning message
    """

    weights_updated = pyqtSignal(dict)
    consistency_failed = pyqtSignal(str)
    consistency_passed = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.engine = AHPEngine()
        self._updating = False  # guard against recursive updates
        self._build_ui()
        self._populate_matrix()
        self._recalculate()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        # Title row
        title_row = QHBoxLayout()
        title = QLabel("AHP Pairwise Comparison Matrix")
        title.setObjectName("title")
        title_row.addWidget(title)
        title_row.addStretch()

        load_btn = QPushButton("Load Excel")
        load_btn.setToolTip("Load matrix from Excel file")
        load_btn.clicked.connect(self._load_excel)
        title_row.addWidget(load_btn)

        export_btn = QPushButton("Export Excel")
        export_btn.clicked.connect(self._export_excel)
        title_row.addWidget(export_btn)

        reset_btn = QPushButton("Reset Defaults")
        reset_btn.clicked.connect(self._reset_defaults)
        title_row.addWidget(reset_btn)
        layout.addLayout(title_row)

        # Scale hint
        hint = QLabel("Saaty Scale: 1=Equal  3=Moderate  5=Strong  7=Very Strong  9=Extreme  (2,4,6,8=intermediate)")
        hint.setObjectName("subtitle")
        layout.addWidget(hint)

        # PCM table
        self.pcm_table = QTableWidget()
        self.pcm_table.setAlternatingRowColors(True)
        self.pcm_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.pcm_table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.pcm_table.itemChanged.connect(self._on_cell_changed)
        layout.addWidget(self.pcm_table)

        # Results section
        results_group = QGroupBox("Consistency & Weights")
        res_layout = QVBoxLayout(results_group)

        # CR status label
        self.cr_label = QLabel("CR = ---")
        self.cr_label.setFont(QFont("Segoe UI", 14, QFont.Bold))
        self.cr_label.setAlignment(Qt.AlignCenter)
        res_layout.addWidget(self.cr_label)

        # Stats row
        stats_row = QHBoxLayout()
        self.n_label = QLabel("n = 7")
        self.lmax_label = QLabel("λmax = ---")
        self.ci_label = QLabel("CI = ---")
        self.ri_label = QLabel("RI = 1.32")
        for lbl in (self.n_label, self.lmax_label, self.ci_label, self.ri_label):
            lbl.setAlignment(Qt.AlignCenter)
            stats_row.addWidget(lbl)
        res_layout.addLayout(stats_row)

        # Weights table
        self.weights_table = QTableWidget()
        self.weights_table.setColumnCount(3)
        self.weights_table.setHorizontalHeaderLabels(["Criterion", "Weight", "Weight %"])
        self.weights_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.weights_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.weights_table.setFixedHeight(220)
        res_layout.addWidget(self.weights_table)

        layout.addWidget(results_group)

    # ------------------------------------------------------------------
    def set_engine(self, engine: AHPEngine) -> None:
        """Replace the current AHP engine and refresh UI."""
        self.engine = engine
        self._populate_matrix()
        self._recalculate()

    def _populate_matrix(self) -> None:
        """Fill the PCM table from the engine's matrix."""
        self._updating = True
        n = len(self.engine.criteria)
        self.pcm_table.setRowCount(n)
        self.pcm_table.setColumnCount(n)
        self.pcm_table.setHorizontalHeaderLabels(self.engine.criteria)
        self.pcm_table.setVerticalHeaderLabels(self.engine.criteria)

        for i in range(n):
            for j in range(n):
                val = self.engine.pcm[i, j]
                item = QTableWidgetItem(self._fmt(val))
                item.setTextAlignment(Qt.AlignCenter)

                if i == j:
                    # Diagonal — locked
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    item.setBackground(QBrush(QColor("#313244")))
                elif i > j:
                    # Below diagonal — auto-filled reciprocal
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    item.setForeground(QBrush(QColor("#6c7086")))
                else:
                    # Above diagonal — user edits here
                    item.setForeground(QBrush(QColor("#89b4fa")))

                self.pcm_table.setItem(i, j, item)

        self._updating = False

    @staticmethod
    def _fmt(val: float) -> str:
        """Format PCM value: fractions as '1/n', integers as int."""
        if val >= 1:
            v = round(val)
            return str(v)
        else:
            recip = round(1.0 / val)
            return f"1/{recip}"

    def _on_cell_changed(self, item: QTableWidgetItem) -> None:
        if self._updating:
            return
        row = item.row()
        col = item.column()
        if row >= col:
            return
        text = item.text().strip()
        try:
            if "/" in text:
                parts = text.split("/")
                val = float(parts[0]) / float(parts[1])
            else:
                val = float(text)
            if val <= 0:
                raise ValueError("Must be positive")
        except Exception:
            self._updating = True
            item.setText(self._fmt(self.engine.pcm[row, col]))
            self._updating = False
            return

        self.engine.set_value(row, col, val)
        self._updating = True
        # Update reciprocal cell
        recip_item = self.pcm_table.item(col, row)
        if recip_item:
            recip_item.setText(self._fmt(self.engine.pcm[col, row]))
        self._updating = False
        self._recalculate()

    def _recalculate(self) -> None:
        """Run AHP and update result display."""
        try:
            result = self.engine.compute()
            self._display_results(result)
        except Exception as e:
            logger.error("AHP compute error: %s", e)
            self.cr_label.setText(f"Error: {e}")

    def _display_results(self, result: AHPResult) -> None:
        self.n_label.setText(f"n = {result.n}")
        self.lmax_label.setText(f"λmax = {result.lambda_max:.4f}")
        self.ci_label.setText(f"CI = {result.ci:.4f}")
        self.ri_label.setText(f"RI = {result.ri:.4f}")

        cr_text = f"CR = {result.cr:.4f}"
        if result.is_consistent:
            cr_text += "  ✓  CONSISTENT"
            self.cr_label.setStyleSheet("color: #a6e3a1; font-weight: bold;")
            self.consistency_passed.emit()
        else:
            cr_text += f"  ✗  INCONSISTENT (threshold {result.cr_threshold})"
            self.cr_label.setStyleSheet("color: #f38ba8; font-weight: bold;")
            self.consistency_failed.emit(
                f"CR = {result.cr:.4f} exceeds the acceptable threshold of {result.cr_threshold}.\n"
                "Please revise the comparison matrix to improve consistency."
            )
        self.cr_label.setText(cr_text)

        # Weights table
        self.weights_table.setRowCount(result.n)
        weight_dict = {}
        for i, (crit, w) in enumerate(zip(result.criteria, result.weights)):
            self.weights_table.setItem(i, 0, QTableWidgetItem(crit))
            self.weights_table.setItem(i, 1, QTableWidgetItem(f"{w:.4f}"))
            self.weights_table.setItem(i, 2, QTableWidgetItem(f"{w*100:.2f}%"))
            weight_dict[crit] = float(w)

        self.weights_updated.emit(weight_dict)

    # ------------------------------------------------------------------
    def _load_excel(self) -> None:
        from PyQt5.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "Load AHP Excel", "", "Excel Files (*.xlsx *.xls)"
        )
        if not path:
            return
        try:
            self.engine.load_from_excel(path)
            self._populate_matrix()
            self._recalculate()
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))

    def _export_excel(self) -> None:
        from PyQt5.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "Export AHP Excel", "ahp_results.xlsx", "Excel Files (*.xlsx)"
        )
        if not path:
            return
        try:
            self.engine.export_to_excel(path)
            QMessageBox.information(self, "Exported", f"AHP results exported to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))

    def _reset_defaults(self) -> None:
        from ahp.ahp_engine import DEFAULT_PCM, DEFAULT_CRITERIA
        self.engine.criteria = list(DEFAULT_CRITERIA)
        self.engine.pcm = DEFAULT_PCM.copy()
        self._populate_matrix()
        self._recalculate()

    def get_weights(self) -> dict[str, float]:
        """Return current criteria weights."""
        if self.engine.result:
            return {c: float(w) for c, w in
                    zip(self.engine.result.criteria, self.engine.result.weights)}
        return {}

    def is_consistent(self) -> bool:
        return bool(self.engine.result and self.engine.result.is_consistent)
