"""
Log Console Widget
===================
Bottom dock panel showing real-time application logs,
progress bar, and status messages.

Thread-safety: _QtLogHandler emits a Qt signal (queued connection)
so log records from worker threads are always processed on the GUI thread,
eliminating the QTextCursor cross-thread warning.
"""

import logging
from datetime import datetime

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit,
    QPushButton, QLabel, QProgressBar,
)
from PyQt5.QtCore import Qt, pyqtSignal, pyqtSlot, QObject
from PyQt5.QtGui import QFont


class _LogSignalBridge(QObject):
    """
    Tiny QObject that lives on the GUI thread and owns a signal.
    Worker threads call bridge.record_ready.emit() which is automatically
    queued to the GUI thread — no QTextCursor cross-thread issue.
    """
    record_ready = pyqtSignal(str, str)   # (formatted_message, level_name)


class LogConsole(QWidget):
    """Scrollable log console with progress bar."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._bridge = _LogSignalBridge()
        self._bridge.record_ready.connect(self.append_message, Qt.QueuedConnection)
        self._build_ui()
        self._install_handler()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(3)

        # Header row
        hdr = QHBoxLayout()
        title = QLabel("Processing Log")
        title.setObjectName("subtitle")
        hdr.addWidget(title)
        hdr.addStretch()

        self.status_label = QLabel("Ready")
        self.status_label.setObjectName("subtitle")
        hdr.addWidget(self.status_label)

        clear_btn = QPushButton("Clear")
        clear_btn.setFixedHeight(22)
        clear_btn.setFixedWidth(60)
        clear_btn.clicked.connect(self.clear)
        hdr.addWidget(clear_btn)
        layout.addLayout(hdr)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(16)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        # Log text area
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setFixedHeight(140)
        self.log_area.setFont(QFont("Consolas", 11))
        layout.addWidget(self.log_area)

    def _install_handler(self) -> None:
        """Attach a Qt log handler to the root logger."""
        handler = _QtLogHandler(self._bridge)
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S")
        )
        logging.getLogger().addHandler(handler)

    @pyqtSlot(str, str)
    def append_message(self, message: str, level: str = "INFO") -> None:
        """Append a coloured log message. Always called on GUI thread via queued signal."""
        colors = {
            "DEBUG":    "#6c7086",
            "INFO":     "#cdd6f4",
            "WARNING":  "#f9e2af",
            "ERROR":    "#f38ba8",
            "CRITICAL": "#ff0000",
            "SUCCESS":  "#a6e3a1",
        }
        color = colors.get(level.upper(), "#cdd6f4")
        # append() is thread-safe in Qt and auto-scrolls
        self.log_area.append(f'<span style="color:{color};">{message}</span>')

    def log(self, msg: str, level: str = "INFO") -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        self.append_message(f"[{ts}] {msg}", level)

    def clear(self) -> None:
        self.log_area.clear()

    @pyqtSlot(int)
    def set_progress(self, value: int) -> None:
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(value)
        if value >= 100:
            self.progress_bar.setVisible(False)

    @pyqtSlot(str)
    def set_status(self, text: str) -> None:
        self.status_label.setText(text)


class _QtLogHandler(logging.Handler):
    """
    Logging handler that routes records to LogConsole via a queued Qt signal.
    Safe to call from any thread — Qt will marshal the signal to the GUI thread.
    """

    def __init__(self, bridge: _LogSignalBridge) -> None:
        super().__init__()
        self._bridge = bridge

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._bridge.record_ready.emit(msg, record.levelname)
        except Exception:
            pass
