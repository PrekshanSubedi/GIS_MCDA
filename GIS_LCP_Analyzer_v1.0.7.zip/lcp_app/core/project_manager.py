"""
Project Manager
================
Handles serialization and deserialization of an analysis project,
including all layer metadata, AHP matrix, and workflow state.
"""

import json
import logging
from pathlib import Path
from dataclasses import asdict
from typing import Any, Optional
from datetime import datetime

from core.layer_model import LayerInfo, LayerType, LayerRole

logger = logging.getLogger(__name__)

PROJECT_VERSION = "1.0"
PROJECT_EXT = ".lcpproj"


class ProjectManager:
    """Manages save/load of analysis projects."""

    def __init__(self) -> None:
        self.project_path: Optional[Path] = None
        self.is_dirty: bool = False

    # ------------------------------------------------------------------
    # Save
    # ------------------------------------------------------------------
    def save(
        self,
        path: Path,
        layers: list[LayerInfo],
        ahp_matrix: list[list[float]],
        ahp_criteria: list[str],
        settings: dict[str, Any],
    ) -> None:
        """Serialize the project to a JSON file."""
        project = {
            "version": PROJECT_VERSION,
            "created_at": datetime.now().isoformat(),
            "layers": [self._serialize_layer(lyr) for lyr in layers],
            "ahp_matrix": ahp_matrix,
            "ahp_criteria": ahp_criteria,
            "settings": settings,
        }
        path = Path(path)
        if path.suffix != PROJECT_EXT:
            path = path.with_suffix(PROJECT_EXT)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(project, f, indent=2)
        self.project_path = path
        self.is_dirty = False
        logger.info("Project saved to %s", path)

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------
    def load(self, path: Path) -> dict[str, Any]:
        """Deserialize a project from a JSON file."""
        path = Path(path)
        with open(path, "r", encoding="utf-8") as f:
            project = json.load(f)
        self.project_path = path
        self.is_dirty = False
        logger.info("Project loaded from %s", path)
        return project

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _serialize_layer(lyr: LayerInfo) -> dict[str, Any]:
        d = asdict(lyr)
        # Enum fields need string conversion
        d["layer_type"] = lyr.layer_type.name
        d["role"] = lyr.role.value
        return d

    @staticmethod
    def deserialize_layer(d: dict[str, Any]) -> LayerInfo:
        lyr = LayerInfo()
        for k, v in d.items():
            if k == "layer_type":
                setattr(lyr, k, LayerType[v])
            elif k == "role":
                setattr(lyr, k, LayerRole(v))
            elif k == "resolution" and v is not None:
                setattr(lyr, k, tuple(v))
            elif k == "extent" and v is not None:
                setattr(lyr, k, tuple(v))
            elif k == "color" and v is not None:
                setattr(lyr, k, tuple(v))
            else:
                setattr(lyr, k, v)
        return lyr
