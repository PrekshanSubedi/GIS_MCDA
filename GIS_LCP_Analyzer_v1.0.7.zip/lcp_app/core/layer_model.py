"""
Layer Data Models
==================
Defines the Layer classes that represent loaded GIS datasets.
"""

import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Optional, Any
import uuid

logger = logging.getLogger(__name__)


class LayerType(Enum):
    """Supported layer types."""
    RASTER = auto()
    VECTOR_POLYGON = auto()
    VECTOR_POINT = auto()
    VECTOR_LINE = auto()
    UNKNOWN = auto()


class LayerRole(Enum):
    """Semantic role of a layer in the analysis."""
    BUILDINGS = "Buildings"
    SETTLEMENTS = "Settlements"
    DEM = "DEM"
    LULC = "Land Use/Land Cover"
    WATERWAYS = "Waterways"
    ROADS = "Roads"
    STUDY_CORRIDOR = "Study Corridor"
    START_POINT = "Start Point"
    END_POINT = "End Point"
    AUXILIARY = "Auxiliary"


@dataclass
class LayerInfo:
    """Holds metadata about a loaded GIS layer."""
    layer_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = ""
    file_path: str = ""
    layer_type: LayerType = LayerType.UNKNOWN
    role: LayerRole = LayerRole.AUXILIARY
    crs: str = ""
    geometry_type: str = ""
    resolution: Optional[tuple[float, float]] = None  # (xres, yres) for rasters
    band_count: int = 1
    nodata_value: Optional[float] = None
    feature_count: Optional[int] = None
    extent: Optional[tuple[float, float, float, float]] = None  # (minx, miny, maxx, maxy)
    enabled: bool = True
    visible: bool = True
    opacity: float = 1.0
    weight: float = 0.0          # AHP-assigned weight [0–1]
    reclassify_table: list[dict[str, Any]] = field(default_factory=list)
    reprojected_path: Optional[str] = None   # Path to reprojected copy
    rasterized_path: Optional[str] = None    # Path to rasterized version
    color: tuple[int, int, int] = (100, 149, 237)  # RGB display color

    @property
    def is_raster(self) -> bool:
        return self.layer_type == LayerType.RASTER

    @property
    def is_vector(self) -> bool:
        return self.layer_type in (
            LayerType.VECTOR_POLYGON,
            LayerType.VECTOR_POINT,
            LayerType.VECTOR_LINE,
        )

    @property
    def display_name(self) -> str:
        return self.name or Path(self.file_path).stem

    def short_crs(self) -> str:
        """Return a short CRS description."""
        if self.crs:
            if "EPSG:" in self.crs.upper():
                parts = self.crs.upper().split("EPSG:")
                return f"EPSG:{parts[-1].split()[0]}"
            return self.crs[:20]
        return "Unknown"
