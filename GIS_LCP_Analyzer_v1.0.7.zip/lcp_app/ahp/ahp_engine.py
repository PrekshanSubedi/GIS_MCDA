"""
AHP Calculation Engine
=======================
Implements Saaty's Analytical Hierarchy Process:
  - Eigenvector priority weights
  - Consistency Index (CI)
  - Consistency Ratio (CR)
  - Excel import/export

Reference: Saaty, T.L. (1980). The Analytic Hierarchy Process. McGraw-Hill.
"""

import logging
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# Saaty's Random Index table (n = 1 to 15)
SAATY_RI = {
    1: 0.00, 2: 0.00, 3: 0.58, 4: 0.90, 5: 1.12,
    6: 1.24, 7: 1.32, 8: 1.41, 9: 1.45, 10: 1.49,
    11: 1.51, 12: 1.48, 13: 1.56, 14: 1.57, 15: 1.59,
}

# Default criteria matching GIS-TL-DS-2026-001
DEFAULT_CRITERIA = [
    "Buildings", "Settlement", "Slope", "TRI",
    "Land Use", "Waterways", "Roads",
]

# Default pairwise comparison matrix from the Excel file
DEFAULT_PCM = np.array([
    [1,    2,    5,    5,    7,    7,    9   ],
    [1/2,  1,    3,    3,    5,    5,    7   ],
    [1/5,  1/3,  1,    2,    3,    3,    5   ],
    [1/5,  1/3,  1/2,  1,    3,    3,    5   ],
    [1/7,  1/5,  1/3,  1/3,  1,    2,    3   ],
    [1/7,  1/5,  1/3,  1/3,  1/2,  1,    3   ],
    [1/9,  1/7,  1/5,  1/5,  1/3,  1/3,  1   ],
], dtype=np.float64)


@dataclass
class AHPResult:
    """Stores the results of an AHP computation."""
    criteria: list[str]
    pcm: np.ndarray
    normalized_matrix: np.ndarray
    weights: np.ndarray                  # priority vector
    weighted_sum_vector: np.ndarray
    lambda_values: np.ndarray            # λ per criterion
    lambda_max: float
    n: int
    ci: float
    ri: float
    cr: float
    cr_threshold: float = 0.10
    warnings: list[str] = field(default_factory=list)

    @property
    def is_consistent(self) -> bool:
        return self.cr <= self.cr_threshold

    def summary(self) -> str:
        lines = [
            "=== AHP Results ===",
            f"n = {self.n}",
            f"λmax = {self.lambda_max:.4f}",
            f"CI   = {self.ci:.4f}",
            f"RI   = {self.ri:.4f}",
            f"CR   = {self.cr:.4f} {'✓ OK' if self.is_consistent else '✗ INCONSISTENT'}",
            "",
            "Priority Weights:",
        ]
        for name, w in zip(self.criteria, self.weights):
            lines.append(f"  {name:<20s}: {w:.4f}  ({w*100:.2f}%)")
        return "\n".join(lines)


class AHPEngine:
    """
    Core AHP calculation engine.

    Usage
    -----
    engine = AHPEngine()
    engine.load_from_excel("path/to/ahp.xlsx")
    result = engine.compute()
    """

    def __init__(
        self,
        criteria: Optional[list[str]] = None,
        pcm: Optional[np.ndarray] = None,
        cr_threshold: float = 0.10,
    ) -> None:
        self.criteria: list[str] = criteria or list(DEFAULT_CRITERIA)
        self.pcm: np.ndarray = pcm if pcm is not None else DEFAULT_PCM.copy()
        self.cr_threshold: float = cr_threshold
        self._result: Optional[AHPResult] = None

    # ------------------------------------------------------------------
    # Load from Excel
    # ------------------------------------------------------------------
    def load_from_excel(self, path: str) -> None:
        """
        Load pairwise comparison matrix from the project Excel file.
        Expects the sheet named '1. Pairwise Comparison Matrix' with
        the format used in GIS-TL-DS-2026-001.
        """
        path = str(path)
        logger.info("Loading AHP matrix from: %s", path)

        # Try to read the pairwise comparison sheet
        try:
            # Read raw sheet to detect structure
            xl = pd.ExcelFile(path)
            sheet_names = xl.sheet_names
            logger.info("Sheets found: %s", sheet_names)

            # Find the pairwise matrix sheet
            pcm_sheet = None
            for sn in sheet_names:
                if "pairwise" in sn.lower() or "comparison" in sn.lower() or "1." in sn:
                    pcm_sheet = sn
                    break
            if pcm_sheet is None:
                pcm_sheet = sheet_names[0]

            df = pd.read_excel(path, sheet_name=pcm_sheet, header=None)

            # Scan for the matrix: find the row that starts with a number
            # and has the criteria names in it
            criteria, matrix = self._parse_pcm_sheet(df)
            if criteria and matrix is not None:
                self.criteria = criteria
                self.pcm = matrix
                logger.info("Loaded %dx%d PCM from sheet '%s'", len(criteria), len(criteria), pcm_sheet)
            else:
                logger.warning("Could not parse PCM from Excel; using defaults.")
        except Exception as e:
            logger.error("Error reading AHP Excel: %s", e, exc_info=True)
            raise

    def _parse_pcm_sheet(
        self, df: pd.DataFrame
    ) -> tuple[list[str], Optional[np.ndarray]]:
        """
        Parse the pairwise comparison matrix from a raw DataFrame.
        Handles the GIS-TL-DS-2026-001 format:
          Row: SN | Criterion | C1 | C2 | ... | Cn
        """
        criteria: list[str] = []
        rows: list[list[float]] = []

        for idx, row in df.iterrows():
            vals = list(row)
            # Skip if first non-null cell is not a small integer (SN column)
            first = next((v for v in vals if pd.notna(v)), None)
            if first is None:
                continue
            try:
                sn = int(float(first))
            except (ValueError, TypeError):
                continue
            if sn < 1 or sn > 20:
                continue

            # The second non-null value is the criterion name
            non_null = [v for v in vals if pd.notna(v)]
            if len(non_null) < 4:
                continue
            criterion_name = str(non_null[1]).strip()
            if not criterion_name or criterion_name.lower() in ("sn", "criterion"):
                continue

            # Collect numeric values after the criterion name
            numeric = []
            collecting = False
            for v in vals[2:]:  # skip SN and Criterion columns
                if pd.isna(v):
                    if collecting:
                        break
                    continue
                try:
                    numeric.append(float(v))
                    collecting = True
                except (ValueError, TypeError):
                    if collecting:
                        break

            if numeric:
                criteria.append(criterion_name)
                rows.append(numeric)

        if not criteria:
            return [], None

        # Build square matrix from collected rows
        n = len(criteria)
        # Trim each row to n values
        matrix = np.zeros((n, n), dtype=np.float64)
        for i, row_vals in enumerate(rows):
            for j, v in enumerate(row_vals[:n]):
                matrix[i, j] = v

        # Fill missing reciprocals
        for i in range(n):
            for j in range(n):
                if matrix[i, j] == 0 and matrix[j, i] != 0:
                    matrix[i, j] = 1.0 / matrix[j, i]
            matrix[i, i] = 1.0  # ensure diagonal is 1

        return criteria, matrix

    # ------------------------------------------------------------------
    # Compute AHP
    # ------------------------------------------------------------------
    def compute(self) -> AHPResult:
        """
        Run the full AHP calculation.

        Steps:
        1. Normalize the PCM by column sums.
        2. Compute priority vector (row averages of normalized matrix).
        3. Compute weighted sum vector (PCM × priority vector).
        4. Compute λmax, CI, RI, CR.
        """
        pcm = self.pcm.copy()
        n = len(self.criteria)
        warnings: list[str] = []

        # Validate matrix dimensions
        if pcm.shape != (n, n):
            raise ValueError(
                f"PCM shape {pcm.shape} does not match criteria count {n}"
            )

        # 1. Column sums
        col_sums = pcm.sum(axis=0)

        # 2. Normalize matrix
        norm = pcm / col_sums[np.newaxis, :]

        # 3. Priority vector (weights) = row means of normalized matrix
        weights = norm.mean(axis=1)
        weights = weights / weights.sum()  # ensure they sum to 1.0

        # 4. Weighted sum vector: PCM @ weights
        wsv = pcm @ weights

        # 5. Lambda values: wsv / weights
        with np.errstate(divide="ignore", invalid="ignore"):
            lambdas = np.where(weights > 0, wsv / weights, 0.0)

        # 6. λmax = mean of lambdas
        lambda_max = float(np.mean(lambdas))

        # 7. CI
        ci = (lambda_max - n) / (n - 1) if n > 1 else 0.0

        # 8. RI from Saaty table
        ri = SAATY_RI.get(n, 1.49)

        # 9. CR
        cr = ci / ri if ri > 0 else 0.0

        if cr > self.cr_threshold:
            warnings.append(
                f"CR = {cr:.4f} exceeds threshold {self.cr_threshold}. "
                "Please revise the pairwise comparison matrix."
            )
            logger.warning("AHP CR = %.4f > threshold %.2f", cr, self.cr_threshold)
        else:
            logger.info("AHP CR = %.4f [OK] (threshold %.2f)", cr, self.cr_threshold)

        self._result = AHPResult(
            criteria=list(self.criteria),
            pcm=pcm,
            normalized_matrix=norm,
            weights=weights,
            weighted_sum_vector=wsv,
            lambda_values=lambdas,
            lambda_max=lambda_max,
            n=n,
            ci=ci,
            ri=ri,
            cr=cr,
            cr_threshold=self.cr_threshold,
            warnings=warnings,
        )
        return self._result

    @property
    def result(self) -> Optional[AHPResult]:
        return self._result

    # ------------------------------------------------------------------
    # Enforce reciprocal symmetry when user edits a cell
    # ------------------------------------------------------------------
    def set_value(self, row: int, col: int, value: float) -> None:
        """
        Set PCM[row, col] = value and PCM[col, row] = 1/value.
        Diagonal stays 1.
        """
        n = len(self.criteria)
        if row == col:
            return
        if not (0 <= row < n and 0 <= col < n):
            raise IndexError("Row/col out of range")
        self.pcm[row, col] = value
        self.pcm[col, row] = 1.0 / value if value != 0 else 0.0

    # ------------------------------------------------------------------
    # Export to Excel
    # ------------------------------------------------------------------
    def export_to_excel(self, path: str) -> None:
        """Export the full AHP analysis to an Excel file."""
        if self._result is None:
            raise RuntimeError("Run compute() before exporting.")
        path = str(path)
        result = self._result
        n = result.n
        criteria = result.criteria

        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            # --- Sheet 1: PCM ---
            pcm_df = pd.DataFrame(
                result.pcm,
                index=criteria,
                columns=criteria,
            )
            pcm_df.to_excel(writer, sheet_name="PCM")

            # --- Sheet 2: Normalized Matrix & Weights ---
            norm_df = pd.DataFrame(
                result.normalized_matrix,
                index=criteria,
                columns=criteria,
            )
            norm_df["Priority Weight"] = result.weights
            norm_df["Weight %"] = result.weights * 100
            norm_df.to_excel(writer, sheet_name="Normalized & Weights")

            # --- Sheet 3: Consistency Check ---
            cc_data = {
                "Criterion": criteria,
                "Weighted Sum": result.weighted_sum_vector,
                "Priority Vector": result.weights,
                "Lambda": result.lambda_values,
            }
            cc_df = pd.DataFrame(cc_data)
            cc_df.loc[len(cc_df)] = ["λmax", result.lambda_max, "", ""]
            cc_df.loc[len(cc_df)] = ["CI", result.ci, "", ""]
            cc_df.loc[len(cc_df)] = ["RI", result.ri, "", ""]
            cc_df.loc[len(cc_df)] = ["CR", result.cr, "", ""]
            cc_df.loc[len(cc_df)] = [
                "Consistent?", "YES" if result.is_consistent else "NO", "", ""
            ]
            cc_df.to_excel(writer, sheet_name="Consistency Check", index=False)

        logger.info("AHP exported to %s", path)
