"""
Raster Processing Module
=========================
Handles:
 - DEM derivative generation (Slope, TRI)
 - Vector rasterization
 - Raster alignment / reprojection
 - Euclidean distance raster generation
 - Reclassification
 - Weighted overlay (WLC cost surface)
 - Chunk-based memory-efficient processing

Dependencies: GDAL, Rasterio, NumPy, Scipy
"""

import logging
import os
import math
from pathlib import Path
from typing import Optional, Callable
import numpy as np

logger = logging.getLogger(__name__)

try:
    import rasterio
    from rasterio.transform import from_bounds, from_origin
    from rasterio import warp
    from rasterio.warp import reproject, Resampling
    from rasterio.features import rasterize as rio_rasterize
    from rasterio.mask import mask as rio_mask
    from rasterio.crs import CRS
    RASTERIO_OK = True
except ImportError:
    RASTERIO_OK = False
    logger.error("Rasterio not available.")

try:
    from osgeo import gdal, ogr, osr
    gdal.UseExceptions()
    GDAL_OK = True
except ImportError:
    GDAL_OK = False
    logger.error("GDAL not available.")

try:
    import geopandas as gpd
    from shapely.geometry import mapping, shape
    GEOPANDAS_OK = True
except ImportError:
    GEOPANDAS_OK = False

try:
    from scipy.ndimage import distance_transform_edt
    SCIPY_OK = True
except ImportError:
    SCIPY_OK = False


# ---------------------------------------------------------------------------
# Raster metadata helper
# ---------------------------------------------------------------------------

def get_raster_info(path: str) -> dict:
    """Return metadata dictionary for a raster file."""
    info: dict = {}
    if not RASTERIO_OK:
        return info
    try:
        with rasterio.open(path) as src:
            info["crs"] = src.crs.to_string() if src.crs else "Unknown"
            info["width"] = src.width
            info["height"] = src.height
            info["band_count"] = src.count
            info["dtype"] = str(src.dtypes[0])
            info["nodata"] = src.nodata
            info["resolution"] = (abs(src.transform.a), abs(src.transform.e))
            bounds = src.bounds
            info["extent"] = (bounds.left, bounds.bottom, bounds.right, bounds.top)
            info["transform"] = src.transform
    except Exception as e:
        logger.error("get_raster_info failed for %s: %s", path, e)
    return info


# ---------------------------------------------------------------------------
# Reprojection
# ---------------------------------------------------------------------------

def reproject_raster(
    src_path: str,
    dst_path: str,
    target_crs: str,
    resampling: str = "bilinear",
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """Reproject a raster to the target CRS."""
    if not RASTERIO_OK:
        raise RuntimeError("Rasterio not installed.")
    resamp = getattr(Resampling, resampling, Resampling.bilinear)
    with rasterio.open(src_path) as src:
        dst_crs = CRS.from_user_input(target_crs)
        transform, width, height = warp.calculate_default_transform(
            src.crs, dst_crs, src.width, src.height, *src.bounds
        )
        kwargs = src.meta.copy()
        kwargs.update({
            "crs": dst_crs,
            "transform": transform,
            "width": width,
            "height": height,
        })
        with rasterio.open(dst_path, "w", **kwargs) as dst:
            for i in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, i),
                    destination=rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    dst_transform=transform,
                    dst_crs=dst_crs,
                    resampling=resamp,
                )
                if progress_cb:
                    progress_cb(i / src.count)
    logger.info("Reprojected raster saved to %s", dst_path)


def reproject_vector(
    src_path: str,
    dst_path: str,
    target_crs: str,
) -> None:
    """Reproject a vector dataset to the target CRS."""
    if not GEOPANDAS_OK:
        raise RuntimeError("GeoPandas not installed.")
    gdf = gpd.read_file(src_path)
    gdf_out = gdf.to_crs(target_crs)
    gdf_out.to_file(dst_path)
    logger.info("Reprojected vector saved to %s", dst_path)


# ---------------------------------------------------------------------------
# Raster alignment
# ---------------------------------------------------------------------------

def align_raster_to_reference(
    src_path: str,
    dst_path: str,
    ref_path: str,
    resampling: str = "bilinear",
) -> None:
    """
    Align a raster (resolution, extent, CRS) to match a reference raster.
    Essential for WLC — all layers must be perfectly co-registered.
    """
    if not RASTERIO_OK:
        raise RuntimeError("Rasterio not installed.")
    resamp = getattr(Resampling, resampling, Resampling.bilinear)
    with rasterio.open(ref_path) as ref:
        ref_crs = ref.crs
        ref_transform = ref.transform
        ref_width = ref.width
        ref_height = ref.height
        ref_nodata = ref.nodata

    with rasterio.open(src_path) as src:
        kwargs = src.meta.copy()
        kwargs.update({
            "crs": ref_crs,
            "transform": ref_transform,
            "width": ref_width,
            "height": ref_height,
        })
        with rasterio.open(dst_path, "w", **kwargs) as dst:
            for i in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, i),
                    destination=rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    dst_transform=ref_transform,
                    dst_crs=ref_crs,
                    resampling=resamp,
                )
    logger.info("Aligned raster saved to %s", dst_path)


# ---------------------------------------------------------------------------
# DEM Derivatives
# ---------------------------------------------------------------------------

def compute_slope(
    dem_path: str,
    slope_path: str,
    units: str = "degree",
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Compute slope from a DEM raster.

    Parameters
    ----------
    dem_path : str
        Path to input DEM (projected CRS expected).
    slope_path : str
        Output path for slope raster.
    units : str
        "degree" or "percent".
    """
    if not RASTERIO_OK or not SCIPY_OK:
        raise RuntimeError("Rasterio + Scipy required for slope.")

    with rasterio.open(dem_path) as src:
        dem = src.read(1).astype(np.float32)
        nodata = src.nodata
        xres = abs(src.transform.a)
        yres = abs(src.transform.e)
        meta = src.meta.copy()

    if nodata is not None:
        dem[dem == nodata] = np.nan

    # Gradient using central differences
    dy, dx = np.gradient(dem, yres, xres)
    rise_run = np.sqrt(dx**2 + dy**2)

    if units == "degree":
        slope = np.degrees(np.arctan(rise_run)).astype(np.float32)
    else:
        slope = (rise_run * 100).astype(np.float32)

    meta.update({"dtype": "float32", "nodata": -9999, "count": 1})
    slope[np.isnan(slope)] = -9999

    with rasterio.open(slope_path, "w", **meta) as dst:
        dst.write(slope, 1)

    logger.info("Slope raster saved to %s", slope_path)
    if progress_cb:
        progress_cb(1.0)


def compute_tri(
    dem_path: str,
    tri_path: str,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Compute Terrain Ruggedness Index (TRI) from a DEM.

    TRI = mean absolute difference between each cell and its 8 neighbors.
    Riley et al. (1999).
    """
    if not RASTERIO_OK:
        raise RuntimeError("Rasterio required.")

    with rasterio.open(dem_path) as src:
        dem = src.read(1).astype(np.float32)
        nodata = src.nodata
        meta = src.meta.copy()

    if nodata is not None:
        dem[dem == nodata] = np.nan

    rows, cols = dem.shape
    tri = np.full_like(dem, np.nan)

    # For each cell, compute mean|center - neighbor| for 3x3 window
    for dr in range(-1, 2):
        for dc in range(-1, 2):
            if dr == 0 and dc == 0:
                continue
            r0 = max(0, dr)
            c0 = max(0, dc)
            r1 = rows + min(0, dr)
            c1 = cols + min(0, dc)
            neighbor = dem[
                max(0, -dr) : rows - max(0, dr),
                max(0, -dc) : cols - max(0, dc),
            ]
            center = dem[r0:r1, c0:c1]
            diff = np.abs(center - neighbor)
            if np.all(np.isnan(tri[r0:r1, c0:c1])):
                tri[r0:r1, c0:c1] = diff
            else:
                tri[r0:r1, c0:c1] = np.nansum(
                    np.stack([tri[r0:r1, c0:c1], diff], axis=0), axis=0
                )

    tri = tri / 8.0  # average over 8 neighbors
    tri_out = tri.astype(np.float32)
    tri_out[np.isnan(tri_out)] = -9999

    meta.update({"dtype": "float32", "nodata": -9999, "count": 1})
    with rasterio.open(tri_path, "w", **meta) as dst:
        dst.write(tri_out, 1)

    logger.info("TRI raster saved to %s", tri_path)
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Euclidean Distance Raster
# ---------------------------------------------------------------------------

def euclidean_distance_raster(
    vector_path: str,
    output_path: str,
    reference_raster_path: str,
    nodata: float = -9999,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Generate a Euclidean distance raster from a vector layer,
    aligned to a reference raster.

    Strategy: rasterize features as binary mask, then distance transform.
    """
    if not (RASTERIO_OK and GEOPANDAS_OK and SCIPY_OK):
        raise RuntimeError("Rasterio, GeoPandas, Scipy required.")

    with rasterio.open(reference_raster_path) as ref:
        ref_transform = ref.transform
        ref_crs = ref.crs
        ref_width = ref.width
        ref_height = ref.height
        xres = abs(ref.transform.a)
        yres = abs(ref.transform.e)

    # Read and reproject vector to reference CRS
    gdf = gpd.read_file(vector_path).to_crs(ref_crs)
    if gdf.empty:
        logger.warning("Empty vector for distance raster: %s", vector_path)
        return

    if progress_cb:
        progress_cb(0.3)

    # Rasterize: 1 where features exist, 0 elsewhere
    shapes = [(geom.__geo_interface__, 1) for geom in gdf.geometry if geom is not None]
    burned = rio_rasterize(
        shapes,
        out_shape=(ref_height, ref_width),
        transform=ref_transform,
        fill=0,
        dtype=np.uint8,
    )

    if progress_cb:
        progress_cb(0.6)

    # Distance transform: distance in pixels, then convert to meters
    dist_pixels = distance_transform_edt(1 - burned)
    # Convert pixel distance to map units (meters if projected CRS)
    pixel_size = (xres + yres) / 2.0
    dist_meters = (dist_pixels * pixel_size).astype(np.float32)

    if progress_cb:
        progress_cb(0.9)

    meta = {
        "driver": "GTiff",
        "dtype": "float32",
        "width": ref_width,
        "height": ref_height,
        "count": 1,
        "crs": ref_crs,
        "transform": ref_transform,
        "nodata": nodata,
        "compress": "lzw",
    }
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(dist_meters, 1)

    logger.info("Distance raster saved to %s", output_path)
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Vector Rasterization
# ---------------------------------------------------------------------------

def rasterize_vector(
    vector_path: str,
    output_path: str,
    reference_raster_path: str,
    burn_value: float = 1.0,
    burn_field: Optional[str] = None,
    all_touched: bool = False,
    nodata: float = 0.0,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Rasterize a vector layer to match a reference raster grid.

    Parameters
    ----------
    vector_path : str
        Input vector file path.
    output_path : str
        Output GeoTIFF path.
    reference_raster_path : str
        Reference raster for grid definition.
    burn_value : float
        Constant value to burn for each feature.
    burn_field : str, optional
        Attribute field to burn (overrides burn_value).
    all_touched : bool
        If True, all pixels touched by geometry are burned.
    """
    if not (RASTERIO_OK and GEOPANDAS_OK):
        raise RuntimeError("Rasterio + GeoPandas required.")

    with rasterio.open(reference_raster_path) as ref:
        ref_transform = ref.transform
        ref_crs = ref.crs
        ref_width = ref.width
        ref_height = ref.height

    gdf = gpd.read_file(vector_path).to_crs(ref_crs)
    if gdf.empty:
        logger.warning("Empty vector for rasterization: %s", vector_path)
        return

    if burn_field and burn_field in gdf.columns:
        shapes = [
            (geom.__geo_interface__, float(val))
            for geom, val in zip(gdf.geometry, gdf[burn_field])
            if geom is not None
        ]
    else:
        shapes = [
            (geom.__geo_interface__, burn_value)
            for geom in gdf.geometry
            if geom is not None
        ]

    burned = rio_rasterize(
        shapes,
        out_shape=(ref_height, ref_width),
        transform=ref_transform,
        fill=nodata,
        dtype=np.float32,
        all_touched=all_touched,
    )

    meta = {
        "driver": "GTiff",
        "dtype": "float32",
        "width": ref_width,
        "height": ref_height,
        "count": 1,
        "crs": ref_crs,
        "transform": ref_transform,
        "nodata": nodata,
        "compress": "lzw",
    }
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(burned, 1)

    logger.info("Rasterized vector saved to %s", output_path)
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Reclassification
# ---------------------------------------------------------------------------

def rasterize_settlement_types(
    vector_path: str,
    output_path: str,
    reference_raster_path: str,
    place_field: str = "place",
    nodata: float = 0.0,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Rasterize settlement points encoding place type as numeric value:
      town=1, village=2, suburb=3, hamlet=4, other=5

    This allows reclassification by place type rather than just distance,
    giving highest routing cost near towns and least near hamlets.

    Parameters
    ----------
    vector_path : str
        Settlement point shapefile.
    place_field : str
        Attribute field containing place type (e.g. 'place', 'type', 'fclass').
    """
    if not (RASTERIO_OK and GEOPANDAS_OK):
        raise RuntimeError("Rasterio + GeoPandas required.")

    PLACE_TYPE_CODES = {
        "town":    1,
        "village": 2,
        "suburb":  3,
        "hamlet":  4,
        "other":   5,
    }

    with rasterio.open(reference_raster_path) as ref:
        ref_transform = ref.transform
        ref_crs = ref.crs
        ref_width = ref.width
        ref_height = ref.height

    gdf = gpd.read_file(vector_path).to_crs(ref_crs)
    if gdf.empty:
        logger.warning("Empty settlement vector: %s", vector_path)
        return

    if progress_cb:
        progress_cb(0.3)

    # Determine which field contains place type
    field = None
    for candidate in [place_field, "place", "type", "fclass", "category", "class"]:
        if candidate in gdf.columns:
            field = candidate
            break

    if field:
        def _code(val):
            v = str(val).lower().strip()
            for key, code in PLACE_TYPE_CODES.items():
                if key in v:
                    return code
            return PLACE_TYPE_CODES["other"]
        shapes = [
            (geom.__geo_interface__, _code(val))
            for geom, val in zip(gdf.geometry, gdf[field])
            if geom is not None
        ]
    else:
        logger.warning("No place-type field found in %s; burning constant 2 (village)", vector_path)
        shapes = [
            (geom.__geo_interface__, 2)
            for geom in gdf.geometry if geom is not None
        ]

    if progress_cb:
        progress_cb(0.6)

    burned = rio_rasterize(
        shapes,
        out_shape=(ref_height, ref_width),
        transform=ref_transform,
        fill=int(nodata),
        dtype=np.uint8,
        all_touched=True,
    )

    meta = {
        "driver": "GTiff",
        "dtype": "uint8",
        "width": ref_width,
        "height": ref_height,
        "count": 1,
        "crs": ref_crs,
        "transform": ref_transform,
        "nodata": 0,
        "compress": "lzw",
    }
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(burned, 1)

    logger.info("Settlement type raster saved to %s", output_path)
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Reclassification
# ---------------------------------------------------------------------------

def reclassify_raster(
    src_path: str,
    dst_path: str,
    reclass_table: list[dict],
    nodata_out: float = -9999,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Reclassify a raster using a lookup table.

    Each entry in reclass_table is:
      {"min": float, "max": float, "value": float}
    Ranges are [min, max).

    For discrete maps (LULC), use min==max as exact-match.
    """
    if not RASTERIO_OK:
        raise RuntimeError("Rasterio required.")

    with rasterio.open(src_path) as src:
        data = src.read(1).astype(np.float64)
        nodata_in = src.nodata
        meta = src.meta.copy()

    if nodata_in is not None:
        mask = data == nodata_in
    else:
        mask = np.zeros(data.shape, dtype=bool)

    result = np.full(data.shape, nodata_out, dtype=np.float32)

    for entry in reclass_table:
        lo = entry.get("min", entry.get("value", 0))
        hi = entry.get("max", entry.get("value", 0))
        out_val = float(entry.get("output", entry.get("cost", 1)))
        if lo == hi:
            # Discrete match
            sel = (data == lo) & ~mask
        else:
            sel = (data >= lo) & (data < hi) & ~mask
        result[sel] = out_val

    result[mask] = nodata_out
    meta.update({"dtype": "float32", "nodata": nodata_out, "count": 1})

    with rasterio.open(dst_path, "w", **meta) as dst:
        dst.write(result, 1)

    logger.info("Reclassified raster saved to %s", dst_path)
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Building Buffer / Constraint Mask
# ---------------------------------------------------------------------------

def create_building_constraint_mask(
    building_path: str,
    output_path: str,
    reference_raster_path: str,
    buffer_m: float = 20.0,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Create a building constraint mask using the formula:
        Con(IsNull("Buildings"), 255, 0)

    Logic:
        - Where buildings exist (after optional buffer): value = 0
          (absolute barrier — LCP will treat 0 as impassable)
        - Where NO buildings exist (IsNull = True):      value = 255
          (fully passable — maximum pass-through value)

    In the WLC cost surface, cells with value 0 are set to np.inf
    (barrier) so Dijkstra will never route through them.

    Parameters
    ----------
    building_path : str
        Path to building footprint vector file.
    reference_raster_path : str
        Reference raster for grid alignment.
    buffer_m : float
        Optional buffer in metres around buildings (0–500m).
    """
    if not (RASTERIO_OK and GEOPANDAS_OK):
        raise RuntimeError("Rasterio + GeoPandas required.")

    gdf = gpd.read_file(building_path)

    with rasterio.open(reference_raster_path) as ref:
        ref_crs       = ref.crs
        ref_transform = ref.transform
        ref_width     = ref.width
        ref_height    = ref.height

    gdf = gdf.to_crs(ref_crs)
    if buffer_m > 0:
        gdf["geometry"] = gdf.geometry.buffer(buffer_m)

    if progress_cb:
        progress_cb(0.4)

    shapes = [(geom.__geo_interface__, 1)
              for geom in gdf.geometry if geom is not None and not geom.is_empty]
    if not shapes:
        logger.warning("No building shapes for constraint mask — writing all-255 mask.")
        # All passable
        mask_arr = np.full((ref_height, ref_width), 255, dtype=np.uint8)
    else:
        # Burn building footprints as 1, background as 0
        burned = rio_rasterize(
            shapes,
            out_shape=(ref_height, ref_width),
            transform=ref_transform,
            fill=0,
            dtype=np.uint8,
            all_touched=True,
        )
        # Con(IsNull("Buildings"), 255, 0)
        # burned==1  → building present  → output 0   (barrier)
        # burned==0  → no building (null) → output 255 (passable)
        mask_arr = np.where(burned == 1, 0, 255).astype(np.uint8)

    if progress_cb:
        progress_cb(0.8)

    meta = {
        "driver":    "GTiff",
        "dtype":     "uint8",
        "width":     ref_width,
        "height":    ref_height,
        "count":     1,
        "crs":       ref_crs,
        "transform": ref_transform,
        "nodata":    255,     # 255 = passable (IsNull region)
        "compress":  "lzw",
    }
    with rasterio.open(output_path, "w", **meta) as dst:
        dst.write(mask_arr, 1)

    n_barrier  = int(np.sum(mask_arr == 0))
    n_passable = int(np.sum(mask_arr == 255))
    logger.info(
        "Building constraint mask [Con(IsNull,255,0)] saved: %s  "
        "barrier=%d px  passable=%d px  buffer=%.1fm",
        output_path, n_barrier, n_passable, buffer_m
    )
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Weighted Linear Combination (WLC) Cost Surface
# ---------------------------------------------------------------------------

def compute_wlc_cost_surface(
    layer_paths: list[str],
    weights: list[float],
    output_path: str,
    constraint_mask_path: Optional[str] = None,
    nodata_out: float = -9999,
    barrier_value: float = np.inf,
    progress_cb: Optional[Callable[[float], None]] = None,
) -> None:
    """
    Compute Weighted Linear Combination cost surface.

    Cost = Sum(wi * Li) for each reclassified raster Li.

    Building constraint mask interpretation (Con(IsNull,255,0)):
        mask==0   → building present  → set cost to +inf (absolute barrier)
        mask==255 → no building       → normal WLC cost applies

    The final cost surface uses np.inf for barriers so Dijkstra
    correctly skips those cells. Nodata cells also become barriers.
    """
    if not RASTERIO_OK:
        raise RuntimeError("Rasterio required.")
    if len(layer_paths) != len(weights):
        raise ValueError("layer_paths and weights must have same length.")

    total_w = sum(weights)
    if abs(total_w - 1.0) > 1e-4:
        logger.warning("Weights sum to %.4f, renormalising to 1.0", total_w)
        weights = [w / total_w for w in weights]

    # Use first layer as reference grid
    with rasterio.open(layer_paths[0]) as ref:
        ref_meta  = ref.meta.copy()
        ref_shape = (ref.height, ref.width)

    accumulator = np.zeros(ref_shape, dtype=np.float64)
    valid_mask  = np.ones(ref_shape,  dtype=bool)   # True = cell is valid

    for i, (path, w) in enumerate(zip(layer_paths, weights)):
        if progress_cb:
            progress_cb(i / len(layer_paths) * 0.75)
        with rasterio.open(path) as src:
            # Always read at reference shape to ensure alignment
            band = src.read(
                1,
                out_shape=ref_shape,
                resampling=Resampling.nearest,
            ).astype(np.float64)
            nd = src.nodata

        # Mark nodata cells as invalid
        bad = np.isnan(band)
        if nd is not None:
            bad |= (band == float(nd))
        valid_mask &= ~bad

        # Zero-out bad cells so they don't corrupt the sum
        band[bad] = 0.0
        accumulator += w * band

    # Build output: valid cells get WLC score, invalid get nodata
    result = np.full(ref_shape, nodata_out, dtype=np.float32)
    result[valid_mask] = accumulator[valid_mask].astype(np.float32)

    if progress_cb:
        progress_cb(0.80)

    # Apply building constraint mask: Con(IsNull("Buildings"), 255, 0)
    # mask==0 means building present → absolute barrier (np.inf stored as 99999)
    BARRIER = 99999.0
    if constraint_mask_path and Path(constraint_mask_path).exists():
        with rasterio.open(constraint_mask_path) as cm:
            cmask = cm.read(1, out_shape=ref_shape, resampling=Resampling.nearest)
        # Cells where mask==0 are buildings → hard barrier
        result[cmask == 0] = BARRIER
        n_blocked = int(np.sum(cmask == 0))
        logger.info("Building barrier cells: %d px (cost=%.0f)", n_blocked, BARRIER)

    if progress_cb:
        progress_cb(0.90)

    ref_meta.update({
        "dtype":   "float32",
        "nodata":  nodata_out,
        "count":   1,
        "compress":"lzw",
    })
    with rasterio.open(output_path, "w", **ref_meta) as dst:
        dst.write(result, 1)

    valid_cells   = int(np.sum(valid_mask))
    barrier_cells = int(np.sum(result == BARRIER))
    logger.info(
        "WLC cost surface saved: %s  valid=%d  barriers=%d",
        output_path, valid_cells, barrier_cells
    )
    if progress_cb:
        progress_cb(1.0)


# ---------------------------------------------------------------------------
# Clip raster to study corridor
# ---------------------------------------------------------------------------

def clip_raster_to_polygon(
    src_path: str,
    dst_path: str,
    polygon_path: str,
    target_crs: Optional[str] = None,
) -> None:
    """Clip a raster to the extent of a polygon boundary."""
    if not (RASTERIO_OK and GEOPANDAS_OK):
        raise RuntimeError("Rasterio + GeoPandas required.")
    gdf = gpd.read_file(polygon_path)
    with rasterio.open(src_path) as src:
        if target_crs or gdf.crs != src.crs:
            gdf = gdf.to_crs(src.crs)
        shapes = [geom.__geo_interface__ for geom in gdf.geometry]
        out_image, out_transform = rio_mask(src, shapes, crop=True)
        out_meta = src.meta.copy()
    out_meta.update({
        "driver": "GTiff",
        "height": out_image.shape[1],
        "width": out_image.shape[2],
        "transform": out_transform,
        "compress": "lzw",
    })
    with rasterio.open(dst_path, "w", **out_meta) as dst:
        dst.write(out_image)
    logger.info("Clipped raster saved to %s", dst_path)
