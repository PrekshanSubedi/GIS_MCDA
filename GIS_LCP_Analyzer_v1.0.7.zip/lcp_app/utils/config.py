"""
Application Configuration Manager
====================================
Handles loading/saving application settings via JSON config file.
"""

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "theme": "dark",
    "default_output_dir": "",
    "default_buffer_m": 20,
    "cr_threshold": 0.10,
    "default_crs": "EPSG:32645",
    "cache_dir": "",
    "auto_cleanup": True,
    "log_level": "INFO",
    "chunk_size": 1024,
    "max_memory_mb": 2048,
    "recent_projects": [],
    "window_width": 1600,
    "window_height": 900,
}

CONFIG_FILE = Path.home() / ".gis_lcp_analyzer" / "config.json"


class AppConfig:
    """Manages application-wide configuration."""

    def __init__(self) -> None:
        self._config: dict[str, Any] = dict(DEFAULT_CONFIG)
        self._load()

    def _load(self) -> None:
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r") as f:
                    stored = json.load(f)
                self._config.update(stored)
                logger.debug("Config loaded from %s", CONFIG_FILE)
            except Exception as e:
                logger.warning("Failed to load config: %s", e)

    def save(self) -> None:
        try:
            CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(CONFIG_FILE, "w") as f:
                json.dump(self._config, f, indent=2)
            logger.debug("Config saved to %s", CONFIG_FILE)
        except Exception as e:
            logger.warning("Failed to save config: %s", e)

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._config[key] = value
        self.save()

    def add_recent_project(self, path: str) -> None:
        recent = self._config.get("recent_projects", [])
        if path in recent:
            recent.remove(path)
        recent.insert(0, path)
        self._config["recent_projects"] = recent[:10]
        self.save()

    def all(self) -> dict[str, Any]:
        return dict(self._config)
