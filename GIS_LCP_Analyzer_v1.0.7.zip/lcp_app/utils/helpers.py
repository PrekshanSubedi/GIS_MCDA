"""
General Utility Helpers
========================
Miscellaneous helper functions used throughout the application.
"""

import logging
import tempfile
import shutil
from pathlib import Path
from typing import Optional
import numpy as np

logger = logging.getLogger(__name__)


def get_temp_dir() -> Path:
    """Create and return a per-session temp directory."""
    tmp = Path(tempfile.gettempdir()) / "gis_lcp_workspace"
    tmp.mkdir(parents=True, exist_ok=True)
    return tmp


def cleanup_temp_dir() -> None:
    """Remove the session temp directory."""
    tmp = Path(tempfile.gettempdir()) / "gis_lcp_workspace"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
        logger.info("Temp workspace cleaned up.")


def normalize_array(arr: np.ndarray, nodata: float = np.nan) -> np.ndarray:
    """
    Normalize a 2D numpy array to [0, 1] range, ignoring nodata values.

    Parameters
    ----------
    arr : np.ndarray
        Input array.
    nodata : float
        Value to treat as nodata (will be excluded from min/max).

    Returns
    -------
    np.ndarray
        Normalized array with same shape. Nodata positions are NaN.
    """
    result = arr.astype(np.float32)
    mask = np.isnan(result)
    if not np.isnan(nodata):
        mask |= (result == nodata)
    result[mask] = np.nan
    valid = result[~mask]
    if valid.size == 0:
        return result
    mn, mx = float(np.nanmin(valid)), float(np.nanmax(valid))
    if mx == mn:
        result[~mask] = 0.5
    else:
        result[~mask] = (result[~mask] - mn) / (mx - mn)
    return result


def meters_to_degrees(meters: float, lat: float = 27.7) -> float:
    """Approximate conversion of meters to degrees at a given latitude."""
    deg_lat = meters / 111_320.0
    import math
    deg_lon = meters / (111_320.0 * math.cos(math.radians(lat)))
    return max(deg_lat, deg_lon)


def human_readable_size(size_bytes: int) -> str:
    """Convert bytes to human-readable string."""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def safe_float(value: str, default: float = 0.0) -> float:
    """Safely convert string to float."""
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def validate_coordinate(lat: float, lon: float) -> bool:
    """Check if a WGS84 coordinate is valid."""
    return -90 <= lat <= 90 and -180 <= lon <= 180
