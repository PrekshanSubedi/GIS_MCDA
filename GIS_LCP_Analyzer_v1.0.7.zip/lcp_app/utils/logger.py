"""
Logging Configuration
======================
Sets up file + console logging for the application.
"""

import logging
from pathlib import Path

LOG_DIR = Path.home() / ".gis_lcp_analyzer" / "logs"
LOG_FILE = LOG_DIR / "gis_lcp.log"


def setup_logging(level: str = "INFO") -> None:
    """Configure application-wide logging."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    log_level = getattr(logging, level.upper(), logging.INFO)

    fmt = "%(asctime)s [%(levelname)-8s] %(name)s: %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    formatter = logging.Formatter(fmt, datefmt)

    root = logging.getLogger()
    root.setLevel(log_level)

    # Console handler — force UTF-8 on Windows to avoid cp1252 UnicodeEncodeError
    import sys, io
    try:
        stream = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    except AttributeError:
        stream = sys.stdout  # fallback (already a TextIOWrapper, e.g. in some IDEs)
    ch = logging.StreamHandler(stream)
    ch.setFormatter(formatter)
    ch.setLevel(log_level)
    root.addHandler(ch)

    # File handler (rotating) — always UTF-8
    try:
        from logging.handlers import RotatingFileHandler
        fh = RotatingFileHandler(LOG_FILE, maxBytes=5_000_000, backupCount=3, encoding="utf-8")
        fh.setFormatter(formatter)
        fh.setLevel(log_level)
        root.addHandler(fh)
    except Exception:
        pass

    # Suppress noisy third-party loggers
    for lib in ("rasterio", "fiona", "pyproj", "shapely", "matplotlib"):
        logging.getLogger(lib).setLevel(logging.WARNING)
